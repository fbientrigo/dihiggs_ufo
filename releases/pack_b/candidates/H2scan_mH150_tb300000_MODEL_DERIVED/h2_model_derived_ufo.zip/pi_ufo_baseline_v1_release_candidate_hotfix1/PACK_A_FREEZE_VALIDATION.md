# Pack A Hotfix1 — Independent Freeze Validation

**Freeze status:** `FROZEN`
**Scientific status (inherited from Sol/Hotfix1):** `PASS_WITH_WARNINGS`
**Operator status at intake:** `READY_FOR_FREEZE_REVIEW`
**Freeze timestamp (UTC):** 2026-07-21T03:15:39Z

This is an independent review and freeze pass. It did not reopen the general
scientific audit, redesign the UFO, or modify operator scripts. See
`PACK_A_FREEZE_RECORD.json` in this pack for the full machine-readable
precheck matrix and hash chain.

## Summary of independent re-verification

All gates below were independently re-executed by the freeze reviewer from
fresh clean extractions of the authoritative Hotfix1 candidate
(`pi_ufo_baseline_v1_release_candidate_hotfix1.zip`,
`sha256=d0547c1fa571eb95b2db81deb736c5d73a4f6fc95284bacc5f7229c73c67c4a8`) —
not merely re-read from its own manifest:

- Hash chain for all 8 authoritative inputs/sidecars: **PASS**
- Hotfix1 scope diff against the release candidate: limited exactly to
  `bin/lib/{common,run,reproduce,status,results}.sh`, focused docs,
  `tests/test_pack_a_run_pointers.sh`, `checksums.sha256`, `manifest.json`.
  No physics, card, or process-definition changes. **PASS**
- Eight physics-invariant files byte-identical to the PI original
  (independently re-hashed, not read from the manifest). **PASS**
- `py3_model.pkl` mutable-cache behavior: independently deleted the packaged
  cache in a disposable extraction and re-ran `bin/pack-a run --seed 12345`;
  MG5 regenerated it deterministically and physical output
  (sigma/events/residual) was unchanged. Classified `MUTABLE_DERIVED_CACHE`.
  **PASS**
- ZIP inventory: no `__pycache__`, no stray build artifacts, no venvs, no
  MG5 process directories, no LHE files, no credentials/tokens. **PASS**
- Static integrity (`bash -n`, `sha256sum -c` 133/133, JSON parse, 19/19
  focused pointer tests, preflight from an external working directory):
  **PASS**
- Direct-run regression (`run` -> `status` -> `results`) in a fresh
  extraction: exit 0/0/0; sigma_pb=0.02349 ± 0.0001364; 100 events;
  `.last_run` correctly resolves the direct physical run. **PASS**
- Reproduce regression (`reproduce` -> `status` -> `results`) in a separate
  fresh extraction: exit 0/0/0; `.last_reproduce` points to the wrapper,
  `.last_run` points to the nested physical run; worst four-momentum
  residual 8.199998546842835e-08 GeV. **PASS**
- Pointer failure-path tests (missing / stale / dir-without-events /
  dir-missing-LHE): all deliberate exit 21 with clear `BLOCKED:` messages
  except the "no pointer" case (informational, exit 0); no crash, no
  truncation, parent shell alive in every case. **PASS**
- Repeated-operation test (`run -> status/results -> reproduce ->
  status/results -> run -> status/results -> reproduce -> status/results`)
  in one extraction: `.last_run` advanced monotonically to a distinct
  physical run at every successful step. **PASS**
- Scientific reproduction independently re-run from a fresh extraction:
  exit 0, 100 events, sigma=0.02349 ± 0.0001364 pb, 200 final LLP records
  (2/event, PDG 9000006, status 1, mothers 1 2, no daughters — confirmed by
  reading the raw LHE `<event>` block directly, not only the JSON summary),
  0 non-final LLP records, h2 mass 200 GeV, worst four-momentum residual
  8.199998546842835e-08 GeV (< 1e-6 GeV tolerance). Pythia not executed,
  MadSpin did not decay h2, Pack AA absent, Pack B untouched, recast not
  executed. **PASS**
- Hotfix1 checklist ends exactly `FREEZE_STATUS=NOT_FROZEN` with one
  trailing newline (verified byte-for-byte via `xxd`). **PASS**

## Documentation gap noted (non-blocking)

`PACK_A_HOTFIX1_MANIFEST.json` does not carry `PASS_WITH_WARNINGS` as a
literal JSON field (only `verdict` and `freeze_status` are literal top-level
fields); the scientific status is stated in `README_PACK_A.md` and in
`preflight`/`status` command output. This is a documentation completeness
gap, not a correctness defect, and does not block the freeze. It is closed
explicitly in `PACK_A_FREEZE_RECORD.json`'s `scientific_status` field.

## What this freeze does not do

- Does not reopen the general scientific audit (see
  `PACK_A_SOL_SCIENTIFIC_VALIDATION.md` and `PACK_A_SCIENTIFIC_STATUS.json`
  at the workspace root for that record).
- Does not modify any operator script (`bin/pack-a`, `bin/lib/*.sh`) beyond
  what Hotfix1 already shipped.
- Does not modify any physics file, card, or process definition.
- Does not create Pack AA, touch Pack B, run Pythia, or run the recast.
- Does not overwrite or delete any prior artifact
  (`pi_ufo_baseline_v1_frozen.zip` and its sidecars remain in place,
  explicitly marked historical/non-authoritative).

FREEZE_STATUS=FROZEN
