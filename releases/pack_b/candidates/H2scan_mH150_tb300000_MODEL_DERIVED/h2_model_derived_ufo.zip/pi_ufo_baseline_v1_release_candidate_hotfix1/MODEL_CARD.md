# Model card

## Identity

- Pack: `pi_ufo_baseline_v1`
- Version: `1.0.0`
- Mediator: `H`, PDG 25, SM-like Higgs mass default 125 GeV
- LLP: `h2`, PDG 9000006, real neutral scalar
- Production: custom finite-mass `ggH` form factor followed by `H h2 h2`
- Initial validated multiplicity: zero additional partons only

## Coupling

The runtime UFO preserves `GC_90 = 8*i*Mh2**2/vev` and its historical `QED=-1` label because changing it would alter the PI baseline.

Pack A accepts only `PI_FIXED`.

## Lifetime and decays

Project input is `ctau_mm`. The historical UFO parameter `ctauh2` is metres and is set to `ctau_mm/1000`. The point builder uses

```text
Gamma_total[GeV] = 1.973269804e-13 / ctau_mm
Gamma_i = BR_i * Gamma_total
```

The generated `decay.slha` declares `bb`, `gg`, `gammagamma`, `Zgamma`, `WW`, and `ZZ`. Runtime support is pending until Pythia 8.308 executes the table successfully.
