# PI UFO Baseline v1

    Static status: **PASS**. Pack A native MadGraph/LHE status: **PASS_WITH_WARNINGS**; Pythia, Pack AA, Pack B, and recast were not run.

    ## Classification

    - `PI_PROVIDED_SIMPLIFIED_MODEL`
- `SIMPLIFIED_HEFT_PRODUCTION`
- `FIXED_HPHIPHI_COUPLING`
- `ZERO_JET_ONLY`
- `NOT_FULL_2HDM`

    ## Scope

    This standalone pack implements the initial production chain

    ```text
    g g > H > h2 h2
    ```

    with mediator PDG 25 and LLP PDG 9000006. The LLP remains stable in the LHE.
    Lifetime and branching ratios are applied later through the generated SLHA/Pythia configuration.

    Coupling model: $g_{h\phi\phi}=8m_\phi^2/v$ (fixed by the received UFO).

    This is not a complete 2HDM UFO and does not run 2HDMC point by point. The earlier 2HDMC stage is treated as evidence that long-lived, physically valid regions can exist.

    ## Build a point

    ```bash
    python -m pip install -r requirements.txt
    python scripts/build_point.py \
      --config points/point_000001.yaml \
      --output build/point_000001
    python scripts/run_static_tests.py
    ```

    The build produces `point.json`, `param_card.dat`, `decay.slha`, `proc_card.dat`, `run_card.dat`, `pythia8.cmnd`, and `provenance.json`.

    ## External smoke

    ```bash
    MG5_BIN=/path/to/MG5_aMC_v3_5_3/bin/mg5_aMC scripts/run_mg5_smoke.sh build/point_000001
    PYTHIA8_CONFIG=/path/to/pythia8-config scripts/run_pythia_smoke.sh build/point_000001
    ```

    Recast execution requires an explicit site adapter; see `validation/RECAST_ADAPTER.md`.
