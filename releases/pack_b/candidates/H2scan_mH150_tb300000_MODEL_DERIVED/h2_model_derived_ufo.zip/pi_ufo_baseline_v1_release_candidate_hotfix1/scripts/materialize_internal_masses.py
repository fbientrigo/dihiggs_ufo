#!/usr/bin/env python3
"""Independent cross-check (and process-local fallback) for UFO-internal masses.

MadEvent's own "update missing" command materializes masses for particles
whose mass parameter is internal (derived) rather than external, using the
model's own compiled expression tree. This module re-evaluates the same
UFO-declared expression directly from parameters.py, in pure Python, so the
value MadEvent inserts can be independently verified. It can also, with
--patch, insert a missing BLOCK MASS line into a process-local param_card.dat
copy; it never touches the UFO model files themselves.

Only a whitelisted subset of Python expression syntax is evaluated (names,
numeric literals, +-*/**, unary +-, and cmath./math. attribute calls). Any
other construct, or any identifier that cannot be resolved to a known UFO
parameter, is treated as unsupported and raises ValueError (fail closed).
"""
from __future__ import annotations

import argparse
import ast
import cmath
import importlib
import math
import re
import sys
from pathlib import Path
from typing import Any

_MODULE_NAMES = {'cmath': cmath, 'math': math}
_ALLOWED_NODES = (
    ast.Expression, ast.BinOp, ast.UnaryOp, ast.Call, ast.Name, ast.Load,
    ast.Constant, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.USub,
    ast.UAdd, ast.Attribute,
)


class UnsupportedExpression(ValueError):
    pass


def _check_ast(expr: str, known_names: set[str]) -> ast.Expression:
    tree = ast.parse(expr, mode='eval')
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise UnsupportedExpression(f'unsupported syntax {type(node).__name__!r} in {expr!r}')
        if isinstance(node, ast.Name) and node.id not in known_names and node.id not in _MODULE_NAMES:
            raise UnsupportedExpression(f'unknown identifier {node.id!r} in {expr!r}')
        if isinstance(node, ast.Call):
            ok = (
                isinstance(node.func, ast.Attribute)
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id in _MODULE_NAMES
            )
            if not ok:
                raise UnsupportedExpression(f'unsupported call in {expr!r}')
    return tree


def _safe_eval(expr: str, names: dict[str, float]) -> complex:
    tree = _check_ast(expr, set(names))
    scope: dict[str, Any] = dict(_MODULE_NAMES)
    scope.update(names)
    return eval(compile(tree, '<param-expr>', 'eval'), {'__builtins__': {}}, scope)


def load_ufo_parameters(model_dir: Path) -> dict[str, dict[str, Any]]:
    """Import the UFO's own parameters.py (via its object_library) to get the
    declared name/nature/value/lhablock/lhacode for every Parameter, without
    executing anything beyond the model's own declarative definitions."""
    md = str(model_dir)
    inserted = md not in sys.path
    if inserted:
        sys.path.insert(0, md)
    mod_names = ('object_library', 'function_library', 'parameters')
    for name in mod_names:
        sys.modules.pop(name, None)
    try:
        obj = importlib.import_module('object_library')
        importlib.import_module('function_library')
        importlib.import_module('parameters')
        out = {}
        for p in obj.all_parameters:
            out[p.name] = {
                'nature': p.nature,
                'value': p.value,
                'lhablock': (str(p.lhablock).lower() if getattr(p, 'lhablock', None) else None),
                'lhacode': tuple(int(x) for x in (getattr(p, 'lhacode', None) or [])),
            }
        return out
    finally:
        if inserted and sys.path and sys.path[0] == md:
            sys.path.pop(0)
        for name in mod_names:
            sys.modules.pop(name, None)


def load_ufo_particle_pdg_to_mass_param(model_dir: Path) -> dict[int, str]:
    md = str(model_dir)
    inserted = md not in sys.path
    if inserted:
        sys.path.insert(0, md)
    mod_names = ('object_library', 'function_library', 'parameters', 'particles')
    for name in mod_names:
        sys.modules.pop(name, None)
    try:
        obj = importlib.import_module('object_library')
        importlib.import_module('function_library')
        importlib.import_module('parameters')
        importlib.import_module('particles')
        out = {}
        for particle in obj.all_particles:
            mass = getattr(particle, 'mass', None)
            if mass is not None and getattr(mass, 'name', None) != 'ZERO':
                out[int(particle.pdg_code)] = mass.name
        return out
    finally:
        if inserted and sys.path and sys.path[0] == md:
            sys.path.pop(0)
        for name in mod_names:
            sys.modules.pop(name, None)


def read_param_card_overrides(param_card: Path) -> dict[tuple[str, tuple[int, ...]], float]:
    overrides: dict[tuple[str, tuple[int, ...]], float] = {}
    block: str | None = None
    for raw in param_card.read_text(encoding='utf-8').splitlines():
        line = raw.split('#', 1)[0].strip()
        if not line:
            continue
        m = re.match(r'(?i)^block\s+(\S+)', line)
        if m:
            block = m.group(1).lower()
            continue
        m = re.match(r'(?i)^decay\s+([\d+-]+)\s+([0-9.eE+-]+)', line)
        if m:
            overrides[('decay', (int(m.group(1)),))] = float(m.group(2))
            continue
        if block is None:
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        try:
            code = tuple(int(x) for x in parts[:-1])
            value = float(parts[-1])
        except ValueError:
            continue
        overrides[(block, code)] = value
    return overrides


def resolve_parameter(
    name: str,
    params: dict[str, dict[str, Any]],
    overrides: dict[tuple[str, tuple[int, ...]], float],
    cache: dict[str, float],
    stack: tuple[str, ...] = (),
) -> float:
    if name in cache:
        return cache[name]
    if name in stack:
        raise UnsupportedExpression(f'circular parameter dependency: {" -> ".join(stack + (name,))}')
    if name not in params:
        raise UnsupportedExpression(f'unknown UFO parameter {name!r}')
    p = params[name]
    if p['nature'] == 'external':
        key = (p['lhablock'], p['lhacode'])
        raw = overrides.get(key, p['value'])
        value = complex(raw).real if not isinstance(raw, str) else float(raw)
    else:
        expr = p['value']
        if not isinstance(expr, str):
            value = complex(expr).real
        else:
            needed = sorted({
                node.id for node in ast.walk(ast.parse(expr, mode='eval'))
                if isinstance(node, ast.Name) and node.id not in _MODULE_NAMES
            })
            names = {n: resolve_parameter(n, params, overrides, cache, stack + (name,)) for n in needed}
            result = _safe_eval(expr, names)
            value = result.real if isinstance(result, complex) else float(result)
    cache[name] = value
    return value


def evaluate_pdg_mass(
    model_dir: Path,
    pdg_code: int,
    param_card: Path | None = None,
) -> float:
    params = load_ufo_parameters(model_dir)
    pdg_to_mass = load_ufo_particle_pdg_to_mass_param(model_dir)
    if pdg_code not in pdg_to_mass:
        raise UnsupportedExpression(f'PDG {pdg_code} has no non-zero mass parameter in this UFO')
    mass_name = pdg_to_mass[pdg_code]
    overrides = read_param_card_overrides(param_card) if param_card else {}
    return resolve_parameter(mass_name, params, overrides, {})


def mass_block_has_pdg(param_card: Path, pdg_code: int) -> bool:
    return ('mass', (pdg_code,)) in read_param_card_overrides(param_card)


def patch_missing_mass(param_card: Path, pdg_code: int, value: float, output: Path) -> bool:
    """Fallback only: append a BLOCK MASS entry for pdg_code if missing.
    Idempotent - a second call is a no-op. Never touches the UFO."""
    if mass_block_has_pdg(param_card, pdg_code):
        if output != param_card:
            output.write_text(param_card.read_text(encoding='utf-8'), encoding='utf-8')
        return False
    lines = param_card.read_text(encoding='utf-8').splitlines()
    out_lines = []
    inserted = False
    in_mass_block = False
    for line in lines:
        stripped = line.split('#', 1)[0].strip()
        if re.match(r'(?i)^block\s+mass', stripped):
            in_mass_block = True
            out_lines.append(line)
            continue
        if in_mass_block and re.match(r'(?i)^(block|decay)\s', stripped):
            out_lines.append(f'  {pdg_code:<12} {value:.16e} # added by materialize_internal_masses.py')
            inserted = True
            in_mass_block = False
        out_lines.append(line)
    if in_mass_block and not inserted:
        out_lines.append(f'  {pdg_code:<12} {value:.16e} # added by materialize_internal_masses.py')
        inserted = True
    if not inserted:
        raise UnsupportedExpression('no BLOCK MASS found in param card; cannot append fallback entry')
    output.write_text('\n'.join(out_lines) + '\n', encoding='utf-8')
    return True


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model-dir', required=True, type=Path)
    p.add_argument('--pdg', required=True, type=int)
    p.add_argument('--param-card', type=Path)
    p.add_argument('--check-against', type=float, help='fail if computed value differs by > tolerance')
    p.add_argument('--tolerance', type=float, default=1e-6)
    p.add_argument('--patch', type=Path, help='write a param card with the mass appended if missing')
    args = p.parse_args(argv)
    try:
        value = evaluate_pdg_mass(args.model_dir, args.pdg, args.param_card)
    except UnsupportedExpression as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        return 2
    print(f'{value!r}')
    if args.check_against is not None:
        if abs(value - args.check_against) > args.tolerance:
            print(f'FAIL: computed {value!r} != reference {args.check_against!r}', file=sys.stderr)
            return 3
    if args.patch:
        if not args.param_card:
            print('FAIL: --patch requires --param-card', file=sys.stderr)
            return 2
        patch_missing_mass(args.param_card, args.pdg, value, args.patch)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
