#!/usr/bin/env bash
# Top-level launcher for the Pack A native-runtime validation
# (static tests -> unit tests -> point build -> MG5 import/generate/LHE).
#
# Does NOT use `set -e`: this is meant to be run from an interactive parent
# shell, so each stage is checked explicitly and a failure is reported with
# a clear status line rather than aborting the shell that invoked it.
PACK_ROOT=$(cd "$(dirname "$0")/.." && pwd)
POINT_CONFIG=${1:-"$PACK_ROOT/points/A_PI_NATIVE_200.yaml"}
POINT_DIR=${2:-"$PACK_ROOT/build/A_PI_NATIVE_200"}
STATUS=0

log() { printf '[%s] %s\n' "$(date -u +%FT%TZ)" "$1"; }

run_stage() {
  local name="$1"; shift
  log "STAGE START: $name"
  if "$@"; then
    log "STAGE OK: $name"
  else
    local rc=$?
    log "STAGE FAIL: $name (exit $rc)"
    STATUS=1
  fi
}

cd "$PACK_ROOT" || { echo "BLOCKED: cannot cd to pack root $PACK_ROOT" >&2; exit 20; }

run_stage "static_tests" python3 scripts/run_static_tests.py
run_stage "pytest" python3 -m pytest tests/ -q
run_stage "build_point" python3 scripts/build_point.py --config "$POINT_CONFIG" --output "$POINT_DIR"

if [[ $STATUS -eq 0 ]]; then
  run_stage "mg5_smoke" bash scripts/run_mg5_smoke.sh "$POINT_DIR"
else
  log "STAGE SKIP: mg5_smoke (earlier stage failed)"
fi

if [[ $STATUS -eq 0 ]]; then
  log "PACK_A_NATIVE_RUNTIME_PASS"
else
  log "PACK_A_NATIVE_RUNTIME_FAIL"
fi
exit $STATUS
