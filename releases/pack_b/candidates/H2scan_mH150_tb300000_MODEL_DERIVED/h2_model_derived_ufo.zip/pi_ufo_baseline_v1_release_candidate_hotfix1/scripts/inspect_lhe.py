#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gzip
import json
import math
import re
from pathlib import Path

PDG = 9000006


def opener(path):
    return gzip.open(path, 'rt', encoding='utf-8', errors='replace') if path.suffix == '.gz' else path.open('rt', encoding='utf-8', errors='replace')


def kin(p):
    px, py, pz, e = p
    pt = math.hypot(px, py)
    mass2 = max(0.0, e*e - px*px - py*py - pz*pz)
    mass = math.sqrt(mass2)
    if e > abs(pz):
        y = 0.5 * math.log((e+pz)/(e-pz))
    else:
        y = math.copysign(float('inf'), pz)
    return pt, mass, y


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('lhe', type=Path)
    ap.add_argument('--output', type=Path)
    args = ap.parse_args()
    events = []
    current = None
    with opener(args.lhe) as f:
        for line in f:
            s = line.strip()
            if s == '<event>':
                current = []
                continue
            if s == '</event>':
                events.append(current or [])
                current = None
                continue
            if current is None or not s or s.startswith('#'):
                continue
            fields = s.split()
            if len(fields) < 10:
                continue
            try:
                pid = int(fields[0]); status = int(fields[1])
                px, py, pz, e = map(float, fields[6:10])
            except ValueError:
                continue
            current.append((pid, status, px, py, pz, e))
    final_counts = []
    any_nonfinal = 0
    pt_values = []
    y_values = []
    pair_masses = []
    for ev in events:
        llp = [x for x in ev if abs(x[0]) == PDG]
        finals = [x for x in llp if x[1] == 1]
        any_nonfinal += sum(1 for x in llp if x[1] != 1)
        final_counts.append(len(finals))
        if len(finals) >= 2:
            p4s = []
            for x in finals[:2]:
                p4 = (x[2], x[3], x[4], x[5])
                pt, _, y = kin(p4)
                pt_values.append(pt); y_values.append(y); p4s.append(p4)
            pair = tuple(sum(v[i] for v in p4s) for i in range(4))
            pair_masses.append(kin(pair)[1])
    report = {
        'events': len(events),
        'pdg_llp': PDG,
        'events_with_exactly_two_final_llp': sum(c == 2 for c in final_counts),
        'events_with_wrong_final_llp_count': sum(c != 2 for c in final_counts),
        'nonfinal_llp_records': any_nonfinal,
        'llp_stable_in_lhe': bool(events) and all(c == 2 for c in final_counts) and any_nonfinal == 0,
        'pt_phi_GeV': pt_values,
        'rapidity_phi': y_values,
        'm_phiphi_GeV': pair_masses,
    }
    text = json.dumps(report, indent=2, sort_keys=True) + '\n'
    if args.output:
        args.output.write_text(text, encoding='utf-8')
    else:
        print(text, end='')
    raise SystemExit(0 if report['llp_stable_in_lhe'] else 3)

if __name__ == '__main__':
    main()
