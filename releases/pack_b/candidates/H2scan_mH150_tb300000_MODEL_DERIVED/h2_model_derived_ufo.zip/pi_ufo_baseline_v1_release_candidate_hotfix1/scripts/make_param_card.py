#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from model_utils import PACK_KIND, normalize_point, read_config, write_param_card

p = argparse.ArgumentParser()
p.add_argument('--config', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
a = p.parse_args()
point = normalize_point(read_config(a.config))
overrides = {'Mh2': point['mphi_GeV'], 'ctauh2': point['ctau_m_for_historical_ufo'], 'MH': point['mh_GeV']}
if PACK_KIND == 'B':
    overrides['GHphiphi'] = point['ghphiphi_GeV']
write_param_card(a.output, overrides)
print(a.output)
