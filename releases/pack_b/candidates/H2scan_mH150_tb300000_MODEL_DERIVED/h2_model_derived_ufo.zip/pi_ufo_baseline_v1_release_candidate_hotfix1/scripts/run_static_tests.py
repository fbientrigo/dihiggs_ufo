#!/usr/bin/env python3
from __future__ import annotations
import json
import re
from pathlib import Path
from model_utils import PACK_KIND, PACK_NAME, load_ufo_inventory, normalize_point, pack_root, read_config

root = pack_root()
failures = []

def check(cond, message):
    if not cond:
        failures.append(message)

def re_qed_negative(text):
    return bool(re.search(r"['\"]QED['\"]\s*:\s*-\s*1", text))

def re_jet_process(text):
    return bool(re.search(r'^\s*generate\s+g\s+g\s*>.*\b[jp]\b', text, flags=re.M))

def re_width_auto(text):
    return bool(re.search(r'width\s*=\s*Auto|set\s+Wh2\s+Auto', text, flags=re.I))

try:
    inv = load_ufo_inventory()
    check(9000006 in inv['particle_pdgs'], 'PDG 9000006 missing')
    check(len(inv['h2_vertices']) == 2, f'expected two h2 vertices, got {inv["h2_vertices"]}')
    if PACK_KIND == 'A':
        check(inv['parameters'] == 105, f'Pack A parameter count {inv["parameters"]}')
        check(inv['orders'] == 4, f'Pack A order count {inv["orders"]}')
    else:
        check(inv['parameters'] == 106, f'Pack B parameter count {inv["parameters"]}')
        check(inv['orders'] == 5, f'Pack B order count {inv["orders"]}')
        check(any(o['name'] == 'NP' and o['expansion_order'] >= 1 for o in inv['coupling_orders']), 'NP order missing')
except Exception as exc:
    failures.append(f'UFO import failed: {exc}')

try:
    point = normalize_point(read_config(root / 'points/point_000001.yaml'))
    check(abs(point['br_sum'] - 1.0) <= point['br_sum_tolerance'], 'BR sum failed')
    check(point['pdg_llp'] == 9000006, 'point PDG mismatch')
except Exception as exc:
    failures.append(f'point validation failed: {exc}')

for target in [root / 'model', root / 'cards', root / 'scripts', root / 'points']:
    for path in target.rglob('*'):
        if not path.is_file() or path.suffix not in {'.py','.dat','.cmnd','.yaml','.json','.md','.sh'}:
            continue
        text = path.read_text(encoding='utf-8', errors='replace')
        active_text = '\n'.join(line for line in text.splitlines() if not line.lstrip().startswith('#'))
        if PACK_KIND == 'B' and re_qed_negative(active_text):
            failures.append(f'QED negative order in Pack B: {path.relative_to(root)}')
        if path.suffix == '.dat' and 'generate g g > H > h2 h2,' in active_text:
            failures.append(f'LLP decay chain in process card: {path.relative_to(root)}')
        if path.suffix == '.dat' and re_jet_process(active_text):
            failures.append(f'additional-parton process found: {path.relative_to(root)}')
        if re_width_auto(active_text):
            failures.append(f'width Auto found: {path.relative_to(root)}')

report = {'pack': PACK_NAME, 'status': 'PASS' if not failures else 'FAIL', 'failures': failures}
print(json.dumps(report, indent=2, sort_keys=True))
raise SystemExit(0 if not failures else 1)
