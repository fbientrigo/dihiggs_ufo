#!/usr/bin/env bash
set -euo pipefail
PACK_ROOT=$(cd "$(dirname "$0")/.." && pwd)
POINT_DIR=${1:-"$PACK_ROOT/build/point_000001"}
[[ "$POINT_DIR" = /* ]] || POINT_DIR="$PACK_ROOT/$POINT_DIR"
: "${RECAST_CMD:?Set RECAST_CMD to a command template using {input}, {output}, and optionally {variant}; example documented in validation/RECAST_ADAPTER.md}"
INPUT=${RECAST_INPUT:-"$POINT_DIR/pythia_events.hepmc"}
[[ -f "$INPUT" ]] || { echo "BLOCKED: expected recast input $INPUT" >&2; exit 40; }
for variant in A B; do
  OUTPUT="$POINT_DIR/cutflow_${variant}.csv"
  CMD=${RECAST_CMD//\{input\}/$INPUT}
  CMD=${CMD//\{output\}/$OUTPUT}
  CMD=${CMD//\{variant\}/$variant}
  echo "+ $CMD"
  bash -lc "$CMD" | tee "$POINT_DIR/recast_${variant}.log"
  [[ -s "$OUTPUT" ]] || { echo "FAIL: $OUTPUT absent or empty" >&2; exit 41; }
done
