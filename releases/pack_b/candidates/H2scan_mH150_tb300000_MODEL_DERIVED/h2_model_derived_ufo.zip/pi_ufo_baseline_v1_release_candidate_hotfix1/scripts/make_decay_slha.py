#!/usr/bin/env python3
import argparse
from pathlib import Path
from model_utils import normalize_point, read_config, write_decay_slha
p = argparse.ArgumentParser()
p.add_argument('--config', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
a = p.parse_args()
write_decay_slha(normalize_point(read_config(a.config)), a.output)
print(a.output)
