#!/usr/bin/env bash
set -euo pipefail
PACK_ROOT=$(cd "$(dirname "$0")/.." && pwd)
POINT_DIR=${1:-"$PACK_ROOT/build/point_000001"}
[[ "$POINT_DIR" = /* ]] || POINT_DIR="$PACK_ROOT/$POINT_DIR"
PYTHIA8_CONFIG=${PYTHIA8_CONFIG:-$(command -v pythia8-config || true)}
if [[ -z "$PYTHIA8_CONFIG" ]]; then
  echo "BLOCKED: set PYTHIA8_CONFIG or provide pythia8-config from Pythia 8.308" >&2
  exit 30
fi
LHE=${LHE_FILE:-$(find "$POINT_DIR" -type f \( -name '*.lhe' -o -name '*.lhe.gz' \) | sort | head -1)}
[[ -n "$LHE" ]] || { echo 'BLOCKED: no LHE file; run run_mg5_smoke.sh first' >&2; exit 31; }
CXX=${CXX:-c++}
BIN="$POINT_DIR/pythia_llp_smoke"
$CXX -O2 -std=c++17 "$PACK_ROOT/validation/pythia_llp_smoke.cc" -o "$BIN" \
  $($PYTHIA8_CONFIG --cxxflags) $($PYTHIA8_CONFIG --libs)
"$BIN" "$LHE" "$POINT_DIR/decay.slha" "$POINT_DIR/point.json" "$POINT_DIR/pythia_metrics.csv" "$POINT_DIR/pythia_summary.json"
cat "$POINT_DIR/pythia_summary.json"
