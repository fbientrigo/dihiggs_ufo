from __future__ import annotations

import cmath
import hashlib
import importlib
import json
import math
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

try:
    import jsonschema
except ImportError:  # pragma: no cover
    jsonschema = None

from pack_constants import MODEL_SUBDIR, PACK_CREATED_AT, PACK_KIND, PACK_NAME, PACK_VERSION

HBAR_C_GEV_MM = 1.973269804e-13
BR_SUM_TOLERANCE = 1.0e-9
PDG_LLP = 9000006
PDG_MEDIATOR = 25
MH_DEFAULT_GEV = 125.0

CHANNELS = {
    'bb': {'daughters': [5, -5], 'threshold_GeV': 2.0 * 4.18},
    'gg': {'daughters': [21, 21], 'threshold_GeV': 0.0},
    'gammagamma': {'daughters': [22, 22], 'threshold_GeV': 0.0},
    'Zgamma': {'daughters': [23, 22], 'threshold_GeV': 91.1876},
    'WW': {'daughters': [24, -24], 'threshold_GeV': 2.0 * 79.82435974619784},
    'ZZ': {'daughters': [23, 23], 'threshold_GeV': 2.0 * 91.1876},
}


def pack_root() -> Path:
    return Path(__file__).resolve().parents[1]


def model_dir() -> Path:
    return pack_root() / MODEL_SUBDIR


def read_config(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding='utf-8')
    if path.suffix.lower() == '.json':
        data = json.loads(text)
    else:
        if yaml is None:
            raise RuntimeError('PyYAML is required for YAML input; JSON remains supported')
        data = yaml.safe_load(text)
    if not isinstance(data, dict):
        raise ValueError('Point config must be a mapping/object')
    return data


def validate_schema(data: dict[str, Any]) -> None:
    schema_path = pack_root() / 'schemas/point.schema.json'
    schema = json.loads(schema_path.read_text(encoding='utf-8'))
    if jsonschema is not None:
        jsonschema.validate(data, schema)
        return
    required = schema.get('required', [])
    missing = [x for x in required if x not in data]
    if missing:
        raise ValueError(f'Missing required fields: {missing}')


def compute_ufo_default_vev() -> float:
    aewm1 = 127.9
    gf = 0.0000116637
    mz = 91.1876
    aew = 1.0 / aewm1
    mw = math.sqrt(mz**2 / 2.0 + math.sqrt(mz**4 / 4.0 - (aew * math.pi * mz**2) / (gf * math.sqrt(2.0))))
    ee = 2.0 * math.sqrt(aew) * math.sqrt(math.pi)
    sw = math.sqrt(1.0 - mw**2 / mz**2)
    return 2.0 * mw * sw / ee


def pi_fixed_coupling(mphi_GeV: float, vev_GeV: float) -> float:
    return 8.0 * mphi_GeV**2 / vev_GeV


def alignment_coupling(mh_GeV: float, mphi_GeV: float, Mbar2_GeV2: float, vev_GeV: float) -> float:
    return (mh_GeV**2 + 2.0 * mphi_GeV**2 - 2.0 * Mbar2_GeV2) / vev_GeV


def total_width_from_ctau(ctau_mm: float) -> float:
    return HBAR_C_GEV_MM / ctau_mm


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def normalize_point(data: dict[str, Any]) -> dict[str, Any]:
    validate_schema(data)
    errors: list[str] = []
    warnings: list[str] = []

    mphi = float(data['mphi_GeV'])
    ctau_mm = float(data['ctau_mm'])
    if not math.isfinite(mphi) or mphi <= 0:
        errors.append('mphi_GeV must be finite and > 0')
    if not math.isfinite(ctau_mm) or ctau_mm <= 0:
        errors.append('ctau_mm must be finite and > 0')

    brs = data.get('branching_ratios', {})
    unknown = sorted(set(brs) - set(CHANNELS))
    if unknown:
        errors.append(f'Unknown decay channels: {unknown}')
    normalized_brs: dict[str, float] = {}
    for name in CHANNELS:
        value = float(brs.get(name, 0.0))
        if not math.isfinite(value) or value < 0.0 or value > 1.0:
            errors.append(f'BR({name}) must be finite and in [0,1]')
        normalized_brs[name] = value
        if value > 0.0 and mphi + 1e-12 < CHANNELS[name]['threshold_GeV']:
            errors.append(
                f'Channel {name} is kinematically closed at mphi={mphi} GeV; '
                f'threshold={CHANNELS[name]["threshold_GeV"]:.12g} GeV'
            )
    br_sum = sum(normalized_brs.values())
    if abs(br_sum - 1.0) > BR_SUM_TOLERANCE:
        errors.append(f'Branching ratios sum to {br_sum:.17g}; tolerance is {BR_SUM_TOLERANCE:g}')

    vev = float(data.get('vev_GeV', compute_ufo_default_vev()))
    mh = float(data.get('mh_GeV', MH_DEFAULT_GEV))
    mode = str(data.get('coupling_mode', 'PI_FIXED')).upper()
    mbar2 = data.get('Mbar2_GeV2')

    if PACK_KIND == 'A':
        if mode != 'PI_FIXED':
            errors.append('Pack A only accepts coupling_mode=PI_FIXED')
        gh = pi_fixed_coupling(mphi, vev)
        mode = 'PI_FIXED'
    else:
        if mode == 'PI_FIXED':
            gh = pi_fixed_coupling(mphi, vev)
        elif mode == '2HDMC_ALIGNMENT':
            if mbar2 is None:
                errors.append('2HDMC_ALIGNMENT requires Mbar2_GeV2')
                gh = float('nan')
            else:
                gh = alignment_coupling(mh, mphi, float(mbar2), vev)
        elif mode == 'FREE_COUPLING':
            if 'ghphiphi_GeV' not in data:
                errors.append('FREE_COUPLING requires ghphiphi_GeV')
                gh = float('nan')
            else:
                gh = float(data['ghphiphi_GeV'])
                if not math.isfinite(gh):
                    errors.append('ghphiphi_GeV must be finite')
        else:
            errors.append(f'Unknown coupling_mode: {mode}')
            gh = float('nan')

    if errors:
        raise ValueError('; '.join(errors))

    total_width = total_width_from_ctau(ctau_mm)
    partial = {name: br * total_width for name, br in normalized_brs.items()}
    runtime_status = {
        name: ('DECLARED_BUT_RUNTIME_PENDING' if br > 0 else 'DISABLED')
        for name, br in normalized_brs.items()
    }
    return {
        'schema_version': '1.0.0',
        'model_pack': PACK_NAME,
        'pack_version': PACK_VERSION,
        'physics_classification': PACK_CLASSIFICATION,
        'point_id': str(data['point_id']),
        'mphi_GeV': mphi,
        'mh_GeV': mh,
        'pdg_llp': PDG_LLP,
        'pdg_mediator': PDG_MEDIATOR,
        'coupling_mode': mode,
        'ghphiphi_GeV': gh,
        'ghphiphi_vertex_convention': 'UFO GC_90 uses +i*GHphiphi; reported GHphiphi is the real coefficient',
        'Mbar2_GeV2': (float(mbar2) if mbar2 is not None else None),
        'vev_GeV': vev,
        'ctau_mm': ctau_mm,
        'ctau_m_for_historical_ufo': ctau_mm / 1000.0,
        'total_width_GeV': total_width,
        'branching_ratios': normalized_brs,
        'partial_widths_GeV': partial,
        'decay_runtime_status': runtime_status,
        'br_sum': br_sum,
        'br_sum_tolerance': BR_SUM_TOLERANCE,
        'hbar_c_GeV_mm': HBAR_C_GEV_MM,
        'seed': int(data.get('seed', 12345)),
        'warnings': warnings,
        'validation_state': 'STATIC_POINT_VALIDATED_RUNTIME_PENDING',
    }


PACK_CLASSIFICATION = []  # overwritten below by pack_constants import side effect guard
try:
    from pack_constants import CLASSIFICATION as PACK_CLASSIFICATION
except ImportError:
    pass


def _clear_ufo_modules() -> None:
    for name in [
        'object_library', 'function_library', 'parameters', 'particles', 'couplings',
        'lorentz', 'form_factors', 'vertices', 'coupling_orders', 'decays', 'propagators'
    ]:
        sys.modules.pop(name, None)


def load_ufo_inventory() -> dict[str, Any]:
    _clear_ufo_modules()
    md = model_dir()
    sys.path.insert(0, str(md))
    try:
        obj = importlib.import_module('object_library')
        importlib.import_module('function_library')
        importlib.import_module('parameters')
        importlib.import_module('particles')
        importlib.import_module('couplings')
        importlib.import_module('lorentz')
        importlib.import_module('form_factors')
        importlib.import_module('vertices')
        importlib.import_module('coupling_orders')
        importlib.import_module('decays')
        return {
            'particles': len(obj.all_particles),
            'parameters': len(obj.all_parameters),
            'couplings': len(obj.all_couplings),
            'vertices': len(obj.all_vertices),
            'lorentz': len(obj.all_lorentz),
            'orders': len(obj.all_orders),
            'decays': len(obj.all_decays),
            'form_factors': len(obj.all_form_factors),
            'particle_pdgs': sorted(int(p.pdg_code) for p in obj.all_particles),
            'h2_vertices': [
                {
                    'name': v.name,
                    'particles': [p.name for p in v.particles],
                    'lorentz': [x.name for x in v.lorentz],
                    'couplings': sorted(c.name for c in v.couplings.values()),
                }
                for v in obj.all_vertices if any(p.name == 'h2' for p in v.particles)
            ],
            'coupling_orders': [
                {'name': o.name, 'expansion_order': o.expansion_order, 'hierarchy': o.hierarchy}
                for o in obj.all_orders
            ],
            'h2_pdg': next(int(p.pdg_code) for p in obj.all_particles if p.name == 'h2'),
            'gc90': {
                'value': next(c.value for c in obj.all_couplings if c.name == 'GC_90'),
                'order': next(c.order for c in obj.all_couplings if c.name == 'GC_90'),
            },
        }
    finally:
        if sys.path and sys.path[0] == str(md):
            sys.path.pop(0)
        _clear_ufo_modules()


def write_param_card(output: Path, overrides: dict[str, float]) -> None:
    _clear_ufo_modules()
    md = model_dir()
    sys.path.insert(0, str(md))
    try:
        obj = importlib.import_module('object_library')
        importlib.import_module('function_library')
        importlib.import_module('parameters')
        params = [p for p in obj.all_parameters if getattr(p, 'nature', None) == 'external']
    finally:
        if sys.path and sys.path[0] == str(md):
            sys.path.pop(0)
        _clear_ufo_modules()

    names = {p.name for p in params}
    unknown = sorted(set(overrides) - names)
    if unknown:
        raise ValueError(f'Unknown param-card overrides: {unknown}')
    blocks: dict[str, list[tuple[tuple[int, ...], float, str]]] = defaultdict(list)
    decays: list[tuple[tuple[int, ...], float, str]] = []
    for p in params:
        value = complex(overrides.get(p.name, p.value)).real
        block = str(p.lhablock).upper()
        row = (tuple(int(x) for x in p.lhacode), value, p.name)
        if block == 'DECAY':
            decays.append(row)
        else:
            blocks[block].append(row)
    lines = [
        '# Generated by 2Higgs UFO pack point builder',
        '# FRBLOCK 2 ctauh2 is metres; project input and Pythia tau0 are millimetres.',
        '# Do not replace the LLP width by Auto.',
        '',
    ]
    for block in sorted(blocks):
        lines.append(f'BLOCK {block}')
        for code, value, name in sorted(blocks[block]):
            index = ' '.join(str(x) for x in code)
            lines.append(f'  {index:<12} {value:.16e} # {name}')
        lines.append('')
    for code, value, name in sorted(decays):
        lines.append(f'DECAY {code[0]:>9d} {value:.16e} # {name}')
    lines.append('')
    output.write_text('\n'.join(lines), encoding='utf-8')


def write_decay_slha(point: dict[str, Any], output: Path) -> None:
    lines = [
        '# Phenomenological LLP decay table for Pythia validation',
        '# Runtime support remains DECLARED_BUT_RUNTIME_PENDING until executed.',
        'BLOCK QNUMBERS 9000006 # h2 neutral real scalar',
        '  1  0 # 3 times electric charge',
        '  2  1 # number of spin states',
        '  3  1 # colour representation',
        '  4  0 # self-conjugate',
        'BLOCK MASS',
        f'  9000006 {point["mphi_GeV"]:.16e} # h2',
        f'DECAY 9000006 {point["total_width_GeV"]:.16e} # ctau={point["ctau_mm"]:.16e} mm',
    ]
    for name, spec in CHANNELS.items():
        br = point['branching_ratios'][name]
        if br <= 0:
            continue
        d = spec['daughters']
        lines.append(f'  {br:.16e} 2 {d[0]:>9d} {d[1]:>9d} # {name}')
    lines.append('')
    output.write_text('\n'.join(lines), encoding='utf-8')


def write_proc_card(point: dict[str, Any], output: Path, build_rel: str) -> None:
    lines = [
        '# ZERO_JET_ONLY; LLP must remain stable in the LHE',
        f'import model ./{MODEL_SUBDIR}',
        'generate g g > H > h2 h2',
        f'output {build_rel}/MG5_PROC -f',
        '',
    ]
    output.write_text('\n'.join(lines), encoding='utf-8')


def write_run_card(point: dict[str, Any], output: Path) -> None:
    lines = [
        '# MadGraph LO run-card settings used by scripts/patch_mg5_run_card.py',
        '# This file records deterministic overrides; the external smoke script patches',
        '# the complete default run_card.dat generated by MadGraph 3.5.x.',
        f'{100:>12} = nevents',
        f'{point["seed"]:>12} = iseed',
        f'{1:>12} = lpp1',
        f'{1:>12} = lpp2',
        f'{6500.0:>12.1f} = ebeam1',
        f'{6500.0:>12.1f} = ebeam2',
        f'{0:>12} = ickkw',
        f'{0.0:>12.1f} = xqcut',
        '',
    ]
    output.write_text('\n'.join(lines), encoding='utf-8')


def write_pythia_card(point: dict[str, Any], output: Path) -> None:
    lines = [
        '# Pythia 8.308 smoke configuration; paths are resolved by run_pythia_smoke.sh',
        'Beams:frameType = 4',
        'Beams:LHEF = events.lhe.gz',
        'SLHA:readFrom = 2',
        'SLHA:file = decay.slha',
        'SLHA:useDecayTable = on',
        'SLHA:allowUserOverride = on',
        'ParticleDecays:limitTau0 = off',
        '9000006:mayDecay = on',
        f'9000006:tau0 = {point["ctau_mm"]:.16e}',
        'Next:numberShowEvent = 0',
        'Next:numberShowInfo = 0',
        'Next:numberShowProcess = 0',
        '',
    ]
    output.write_text('\n'.join(lines), encoding='utf-8')
