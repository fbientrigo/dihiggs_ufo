#!/usr/bin/env python3
from __future__ import annotations
import argparse
import re
from pathlib import Path

# Fields MadGraph only emits in run_card.dat for matched/merged (MLM) samples;
# for a ZERO_JET_ONLY process with no additional partons the "Matching" hidden
# block is absent from a freshly generated card, so these must not be required.
OPTIONAL_FIELDS = {'ickkw', 'xqcut'}

REQUIRED_FIELDS = {'nevents', 'iseed', 'lpp1', 'lpp2', 'ebeam1', 'ebeam2'}


def parse_settings(text: str) -> dict[str, str]:
    settings = {}
    for line in text.splitlines():
        raw = line.split('#', 1)[0].strip()
        if not raw or '=' not in raw:
            continue
        value, name = raw.split('=', 1)
        settings[name.strip().split()[0]] = value.strip()
    return settings


def patch_run_card(source_text: str, settings: dict[str, str]) -> str:
    """Substitute `value = name` lines in source_text for every name in
    settings that is present. Raises SystemExit if a REQUIRED_FIELDS entry
    from settings is absent from source_text; entries in OPTIONAL_FIELDS
    (and any other field not in REQUIRED_FIELDS) are silently skipped when
    absent, since MadGraph only emits them for certain process shapes.
    Idempotent: re-applying to already-patched text reproduces it unchanged.
    """
    seen = set()
    out = []
    for line in source_text.splitlines():
        match = re.match(r'^(\s*)([^#!]+?)\s*=\s*([A-Za-z0-9_]+)(.*)$', line)
        if match and match.group(3) in settings:
            name = match.group(3)
            line = f'{match.group(1)}{settings[name]} = {name}{match.group(4)}'
            seen.add(name)
        out.append(line)
    missing = sorted(set(settings) - seen)
    missing_required = [name for name in missing if name in REQUIRED_FIELDS or name not in OPTIONAL_FIELDS]
    if missing_required:
        raise SystemExit(f'Could not patch run-card fields: {missing_required}')
    return '\n'.join(out) + '\n'


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument('--source', required=True, type=Path)
    p.add_argument('--settings', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    a = p.parse_args()
    settings = parse_settings(a.settings.read_text(encoding='utf-8'))
    patched = patch_run_card(a.source.read_text(encoding='utf-8'), settings)
    a.output.write_text(patched, encoding='utf-8')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
