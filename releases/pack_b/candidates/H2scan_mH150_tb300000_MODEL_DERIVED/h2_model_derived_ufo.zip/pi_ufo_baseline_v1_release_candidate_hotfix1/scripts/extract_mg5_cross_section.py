#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
import math
import re
from pathlib import Path

FLOAT = r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[EeDd][+-]?\d+)?'
PATTERNS = [
    ('cross_section_pm', re.compile(rf'Cross[- ]section\s*:\s*({FLOAT})\s*(?:\+/-|\+-)\s*({FLOAT})\s*(?:pb)?', re.I)),
    ('integrated_weight', re.compile(rf'Integrated\s+weight\s*\(pb\)\s*:\s*({FLOAT})', re.I)),
    ('cross_section_pb', re.compile(rf'Cross[- ]section(?:\s*\(pb\))?\s*:\s*({FLOAT})', re.I)),
]

def number(text: str) -> float:
    return float(text.replace('D','E').replace('d','e'))

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--point-dir', type=Path, required=True)
    ap.add_argument('--proc-dir', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    a=ap.parse_args()
    candidates=[]
    for path in [a.point_dir/'mg5_events.log', a.point_dir/'mg5_generate.log']:
        if path.is_file(): candidates.append(path)
    if a.proc_dir.exists():
        candidates.extend(sorted(a.proc_dir.glob('Events/**/*banner*.txt')))
        candidates.extend(sorted(a.proc_dir.glob('Events/**/*results*.dat')))
        candidates.extend(sorted(a.proc_dir.glob('Events/**/*.txt')))
    seen=set(); matches=[]
    for path in candidates:
        try: key=path.resolve()
        except OSError: key=path
        if key in seen or not path.is_file(): continue
        seen.add(key)
        text=path.read_text(encoding='utf-8', errors='replace')
        for pname, pattern in PATTERNS:
            for m in pattern.finditer(text):
                sigma=number(m.group(1)); err=number(m.group(2)) if m.lastindex and m.lastindex >= 2 and m.group(2) else None
                matches.append({'sigma_pb':sigma,'integration_error_pb':err,'pattern':pname,'source':str(path),'offset':m.start()})
    valid=[x for x in matches if math.isfinite(x['sigma_pb']) and x['sigma_pb'] > 0]
    report={'status':'FAIL','sigma_pb':None,'integration_error_pb':None,'source':None,'pattern':None,'matches_found':len(matches)}
    if valid:
        with_error=[x for x in valid if x['integration_error_pb'] is not None and math.isfinite(x['integration_error_pb'])]
        chosen=with_error[-1] if with_error else valid[-1]
        report.update({'status':'PASS', **{k:chosen[k] for k in ['sigma_pb','integration_error_pb','source','pattern']}})
    a.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2,sort_keys=True))
    return 0 if report['status']=='PASS' else 2

if __name__=='__main__':
    raise SystemExit(main())
