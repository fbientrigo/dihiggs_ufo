#!/usr/bin/env bash
set -euo pipefail
PACK_ROOT=$(cd "$(dirname "$0")/.." && pwd)
POINT_DIR=${1:-"$PACK_ROOT/build/point_000001"}
[[ "$POINT_DIR" = /* ]] || POINT_DIR="$PACK_ROOT/$POINT_DIR"
if [[ -z "${MG5_BIN:-}" ]]; then
  MG5_BIN=$(command -v mg5_aMC 2>/dev/null || true)
fi
if [[ -z "${MG5_BIN:-}" ]]; then
  MG5_BIN="$HOME/.local/mg5amcnlo/3.5.3/bin/mg5_aMC"
fi
if [[ ! -x "$MG5_BIN" ]]; then
  echo "BLOCKED: configure MadGraph with: export MG5_BIN=\"$HOME/.local/mg5amcnlo/3.5.3/bin/mg5_aMC\"" >&2
  exit 20
fi
cd "$PACK_ROOT"
[[ -f "$POINT_DIR/proc_card.dat" ]] || python scripts/build_point.py --config points/point_000001.yaml --output "$POINT_DIR"
"$MG5_BIN" "$POINT_DIR/proc_card.dat" | tee "$POINT_DIR/mg5_generate.log"
PROC="$POINT_DIR/MG5_PROC"
cp "$POINT_DIR/param_card.dat" "$PROC/Cards/param_card.dat"
python scripts/patch_mg5_run_card.py --source "$PROC/Cards/run_card.dat" --settings "$POINT_DIR/run_card.dat" --output "$PROC/Cards/run_card.dat.tmp"
mv "$PROC/Cards/run_card.dat.tmp" "$PROC/Cards/run_card.dat"
(
  cd "$PROC"
  # MadEvent 3.5.3 derives PDG-24 (W) mass from internal UFO parameters
  # (MW = f(MZ, Gf, aEW)); the deterministic pack writer only serializes
  # external parameters, so BLOCK MASS never carries an entry for it.
  # The first 0 closes the switch menu; update dependent runs in AskforEditCard
  # and evaluates/materializes internal parameters; the final 0 closes cards.
  printf '0\nupdate dependent\n0\n' | ./bin/generate_events smoke | tee "$POINT_DIR/mg5_events.log"
)
LHE=$(find "$PROC/Events" -type f \( -name 'unweighted_events.lhe.gz' -o -name 'unweighted_events.lhe' \) | sort | tail -1)
[[ -n "$LHE" ]] || { echo 'FAIL: no LHE produced' >&2; exit 21; }
if [[ "$LHE" == *.gz ]]; then cp "$LHE" "$POINT_DIR/events.lhe.gz"; else cp "$LHE" "$POINT_DIR/events.lhe"; fi
python scripts/inspect_lhe.py "$LHE" --output "$POINT_DIR/lhe_report.json"
python scripts/extract_mg5_cross_section.py --point-dir "$POINT_DIR" --proc-dir "$PROC" --output "$POINT_DIR/cross_section.json"
echo "$LHE"
