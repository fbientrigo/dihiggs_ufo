#!/usr/bin/env python3
import argparse
import json
import sys
from pathlib import Path
from model_utils import normalize_point, read_config

p = argparse.ArgumentParser()
p.add_argument('--config', required=True, type=Path)
p.add_argument('--output', type=Path)
a = p.parse_args()
try:
    point = normalize_point(read_config(a.config))
except Exception as exc:
    print(f'INVALID: {exc}', file=sys.stderr)
    raise SystemExit(2)
text = json.dumps(point, indent=2, sort_keys=True) + '\n'
if a.output:
    a.output.write_text(text, encoding='utf-8')
else:
    print(text, end='')
