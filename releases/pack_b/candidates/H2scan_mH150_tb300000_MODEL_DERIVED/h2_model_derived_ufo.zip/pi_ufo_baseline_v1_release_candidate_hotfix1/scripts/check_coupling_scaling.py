#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
import math
import statistics
from pathlib import Path

def main() -> int:
    ap=argparse.ArgumentParser(description='Check sigma proportional to |GHphiphi|^2 at fixed settings')
    ap.add_argument('point_dirs', nargs='+', type=Path)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--base-relative-tolerance', type=float, default=0.05)
    a=ap.parse_args()
    rows=[]; failures=[]
    for d in a.point_dirs:
        try:
            point=json.loads((d/'point.json').read_text())
            xsec=json.loads((d/'cross_section.json').read_text())
            g=float(point['ghphiphi_GeV']); sigma=float(xsec['sigma_pb'])
            err=xsec.get('integration_error_pb'); err=(float(err) if err is not None else None)
            if g == 0 or sigma <= 0 or not math.isfinite(g) or not math.isfinite(sigma):
                raise ValueError('nonzero finite coupling and positive finite cross section required')
            rows.append({'point_dir':str(d),'point_id':point['point_id'],'ghphiphi_GeV':g,'sigma_pb':sigma,'integration_error_pb':err,'sigma_over_g2_pb_per_GeV2':sigma/(g*g)})
        except Exception as exc:
            failures.append(f'{d}: {exc}')
    if len(rows) < 3:
        failures.append('at least three valid points are required')
    reference=statistics.median([r['sigma_over_g2_pb_per_GeV2'] for r in rows]) if rows else None
    for r in rows:
        rel=abs(r['sigma_over_g2_pb_per_GeV2']/reference-1.0) if reference else float('inf')
        stat=0.0 if r['integration_error_pb'] is None else 3.0*abs(r['integration_error_pb']/r['sigma_pb'])
        tol=max(a.base_relative_tolerance,stat)
        r['relative_deviation_from_median']=rel; r['allowed_relative_deviation']=tol; r['pass']=rel <= tol
        if not r['pass']: failures.append(f"{r['point_id']}: sigma/g^2 deviation {rel:.4g} > {tol:.4g}")
    report={'status':'PASS' if not failures else 'FAIL','law':'sigma proportional to |GHphiphi|^2','reference_sigma_over_g2':reference,'points':rows,'failures':failures}
    a.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2,sort_keys=True))
    return 0 if report['status']=='PASS' else 3

if __name__=='__main__':
    raise SystemExit(main())
