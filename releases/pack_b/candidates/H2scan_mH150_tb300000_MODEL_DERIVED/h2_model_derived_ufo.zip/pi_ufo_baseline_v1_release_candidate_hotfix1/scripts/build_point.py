#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from model_utils import (
    PACK_CREATED_AT, PACK_KIND, PACK_NAME, model_dir, normalize_point, pack_root, read_config,
    sha256, write_decay_slha, write_param_card, write_proc_card,
    write_pythia_card, write_run_card,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    try:
        config = read_config(args.config)
        if config.get('model_pack') not in (None, PACK_NAME):
            raise ValueError(f'Config model_pack={config.get("model_pack")!r} does not match {PACK_NAME}')
        point = normalize_point(config)
        out = args.output.resolve()
        out.mkdir(parents=True, exist_ok=True)
        root = pack_root().resolve()
        try:
            build_rel = str(out.relative_to(root))
        except ValueError:
            build_rel = str(out)

        overrides = {
            'Mh2': point['mphi_GeV'],
            'ctauh2': point['ctau_m_for_historical_ufo'],
            'MH': point['mh_GeV'],
        }
        if PACK_KIND == 'B':
            overrides['GHphiphi'] = point['ghphiphi_GeV']

        write_param_card(out / 'param_card.dat', overrides)
        write_decay_slha(point, out / 'decay.slha')
        write_proc_card(point, out / 'proc_card.dat', build_rel)
        write_run_card(point, out / 'run_card.dat')
        write_pythia_card(point, out / 'pythia8.cmnd')
        (out / 'point.json').write_text(json.dumps(point, indent=2, sort_keys=True) + '\n', encoding='utf-8')

        provenance = {
            'generated_at_utc': PACK_CREATED_AT,
            'model_pack': PACK_NAME,
            'pack_kind': PACK_KIND,
            'source_config': str(args.config.resolve()),
            'source_config_sha256': sha256(args.config),
            'runtime_model_dir': str(model_dir().resolve()),
            'runtime_model_files_sha256': {
                str(p.relative_to(model_dir())): sha256(p)
                for p in sorted(model_dir().glob('*.py'))
            },
            'generated_files': ['point.json', 'param_card.dat', 'decay.slha', 'proc_card.dat', 'run_card.dat', 'pythia8.cmnd'],
            'mg5_pythia_recast_state': 'PENDING_EXTERNAL_RUNTIME',
        }
        (out / 'provenance.json').write_text(json.dumps(provenance, indent=2, sort_keys=True) + '\n', encoding='utf-8')
        print(out)
        return 0
    except Exception as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
