# Pack A (native MadGraph/LHE) — operator overview

**What Pack A is:** the PI-provided UFO baseline, run through its own native
production chain `g g > H > h2 h2` (mediator PDG 25, LLP PDG 9000006), with
the coupling fixed by the PI (`GC_90 = 8*complex(0,1)*Mh2**2/vev`). h2 is
generated stable in the LHE. Zero extra partons only.

**What Pack A is not:** it does not run Pythia, does not decay h2, does not
apply MadSpin, is not "Pack AA" (a future separate layer that would consume
this LHE), does not touch "Pack B", and does not execute any recast.

**Release status:** `FROZEN` (Hotfix1; see `PACK_A_FREEZE_RECORD.json` at the
pack root for the freeze record).

**Scientific status:** `PASS_WITH_WARNINGS` (Sol validation — see
`PACK_A_SOL_SCIENTIFIC_VALIDATION.md` at the workspace root). The generated
cross section is classified `PACK_A_LO_SMOKE_XSEC`: usable for baseline
production regression and as stable-LLP LHE input to a later, separate
stage; **not** a publishable production normalization. Full scope in
`docs/PACK_A_SCIENTIFIC_SCOPE.md`.

## Operating the pack

```bash
./bin/pack-a preflight   # verify integrity, toolchain, physics invariants — no generation
./bin/pack-a run         # canonical generation into a fresh runs/<timestamp>_seed.../
./bin/pack-a status      # summary of the most recent run
./bin/pack-a results     # locate and summarize evidence for the most recent run
./bin/pack-a reproduce   # clean extraction + preflight + run + invariant check
./bin/pack-a clean --confirm   # remove interface-generated run directories only
```

`bin/pack-a` is a normal executable — run it, don't `source` it. It resolves
its own location and never depends on your current directory; see
`docs/PACK_A_QUICKSTART.md` for invoking it from outside the pack.

## Logs and evidence

Every `run`/`reproduce` invocation creates a new, timestamped, non-overwritten
directory under `runs/`. Each contains `command.txt`, `environment.json`,
`run.log`, `build_point.log`, `exit_status.txt`, `manifest.json`, and the
generated cards/LHE/validation artifacts. `status` and `results` always
resolve `runs/.last_run` — the most recent *physical* run directory,
whether created directly by `run` or nested inside a `reproduce` clean
extraction — and print an explicit, non-crashing error if that pointer is
missing, stale, or incomplete. `reproduce` also records its own wrapper
directory in `runs/.last_reproduce`, which `status`/`results` never treat as
a physical run. Nothing here is deleted except by `clean --confirm`.

## Scientific scope reference

See `docs/PACK_A_SCIENTIFIC_SCOPE.md`, `PACK_A_SOL_SCIENTIFIC_VALIDATION.md`,
and `PACK_A_REPRODUCIBILITY_MATRIX.json` (workspace root) for the full
validation record this operator layer wraps but does not re-derive.
