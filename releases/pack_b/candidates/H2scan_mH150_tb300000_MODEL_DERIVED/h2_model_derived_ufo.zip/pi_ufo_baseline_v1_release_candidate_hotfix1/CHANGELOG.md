# Changelog

    ## 1.0.0 — 2026-07-16

    - Preserved the received v3 UFO unchanged under `vendor/`.
- Created a source-only runtime copy.
- Replaced only the broken Python-3 standalone param-card writer in the runtime copy.
- Added deterministic point/card builders, lifetime/BR checks, tests, and external validation wrappers.
