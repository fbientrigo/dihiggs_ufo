# Provenance

    - Creation date: `2026-07-16T21:00:00-04:00`
    - Pack version: `1.0.0`
    - Original outer ZIP: `UFO(3).zip`
    - Original outer ZIP SHA-256: `9d5e7d75e177e8b0ae7e4719c955e0ec9cc8dc9f95a8617d1561f5811cffa97d`
    - Audit ZIP SHA-256: `7d9ac9e28c9aa980116064fabca8a2717a6950b07f393e5f7c7a553ce27b1bee`
    - Addendum SHA-256: `1b64e18d3e7fc3e66d79940d885232c634f079f3f73a557ded022ce06ef418f6`
    - Local scanner source SHA-256: `786d630bc989350e49259a41aef834a222f6ef924972d18458aa102b75585246`
    - Python used for local construction: `3.13.5`

    ## File classifications

    - `vendor/LLscalar_v3_UFO_original/**`: `ORIGINAL`
- unchanged runtime physics sources: `ORIGINAL`
- runtime `write_param_card.py`: `TECHNICAL_PATCH`
- all scripts, cards, schemas, tests and documentation: `GENERATED_SUPPORT_FILE`

    Exact inventories and SHA-256 values are in `validation/provenance_inventory.json` and `checksums.sha256`.
