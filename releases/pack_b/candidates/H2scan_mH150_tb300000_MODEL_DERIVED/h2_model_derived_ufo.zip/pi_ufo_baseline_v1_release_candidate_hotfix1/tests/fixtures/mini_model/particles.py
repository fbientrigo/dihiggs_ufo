from object_library import all_particles, Particle
import parameters as Param

ZERO = Param.Parameter(
    name='ZERO', nature='internal', type='real', value='0.0', texname='0',
)

w_plus = Particle(
    pdg_code=24, name='w+', antiname='w-', spin=3, color=1,
    mass=Param.MW, width=ZERO, texname='W', antitexname='W', charge=1,
)

bad_particle = Particle(
    pdg_code=999, name='bad', antiname='bad', spin=1, color=1,
    mass=Param.BAD_MASS, width=ZERO, texname='bad', antitexname='bad', charge=0,
)
