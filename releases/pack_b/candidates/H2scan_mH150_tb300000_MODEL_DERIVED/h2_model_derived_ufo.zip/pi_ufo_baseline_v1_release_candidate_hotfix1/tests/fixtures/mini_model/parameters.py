# Minimal synthetic UFO parameters module for unit-testing
# scripts/materialize_internal_masses.py in isolation from the real, larger
# LLscalar_v3_UFO_runtime model. Reproduces the same structural pattern that
# triggers the missing-PDG-24-mass condition (an internal mass parameter
# derived from external SM inputs), plus one deliberately unsupported
# expression to exercise the fail-closed path.
from object_library import all_parameters, Parameter

MZ = Parameter(
    name='MZ', nature='external', type='real', value=91.1876,
    texname='M_Z', lhablock='MASS', lhacode=[23],
)

Gf = Parameter(
    name='Gf', nature='external', type='real', value=0.0000116637,
    texname='G_f', lhablock='SMINPUTS', lhacode=[2],
)

aEWM1 = Parameter(
    name='aEWM1', nature='external', type='real', value=127.9,
    texname='aEWM1', lhablock='SMINPUTS', lhacode=[1],
)

aEW = Parameter(
    name='aEW', nature='internal', type='real', value='1/aEWM1', texname='alpha_EW',
)

MW = Parameter(
    name='MW', nature='internal', type='real',
    value='cmath.sqrt(MZ**2/2. + cmath.sqrt(MZ**4/4. - (aEW*cmath.pi*MZ**2)/(Gf*cmath.sqrt(2))))',
    texname='M_W',
)

# Deliberately unsupported: no whitelisted UFO parameter uses builtins like
# this, but a hostile or malformed expression must still fail closed rather
# than execute arbitrary code.
BAD_MASS = Parameter(
    name='BAD_MASS', nature='internal', type='real',
    value='__import__("os").getcwd()', texname='BAD',
)
