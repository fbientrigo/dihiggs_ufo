from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))

import pytest
from materialize_internal_masses import (
    UnsupportedExpression,
    evaluate_pdg_mass,
    mass_block_has_pdg,
    patch_missing_mass,
)

REPO_ROOT = Path(__file__).resolve().parents[1]
REAL_MODEL_DIR = REPO_ROOT / 'model' / 'LLscalar_v3_UFO_runtime'
MINI_MODEL_DIR = Path(__file__).resolve().parent / 'fixtures' / 'mini_model'
MISSING_PDG24_CARD = Path(__file__).resolve().parent / 'fixtures' / 'param_card_missing_pdg24.dat'

# The value MadEvent 3.5.3's own "update missing" materialized for this exact
# UFO during the live smoke run (see PACK_A_NATIVE_ROOT_CAUSE.md).
EXPECTED_MW_GEV = 79.82435974619784


def test_process_local_card_reproduces_missing_pdg24_condition():
    assert not mass_block_has_pdg(MISSING_PDG24_CARD, 24)
    text = MISSING_PDG24_CARD.read_text(encoding='utf-8')
    assert 'DECAY        24' in text or 'DECAY 24' in text.replace('        ', ' ')


def test_real_ufo_mw_matches_mg5_materialized_value():
    value = evaluate_pdg_mass(REAL_MODEL_DIR, 24, MISSING_PDG24_CARD)
    assert value == pytest.approx(EXPECTED_MW_GEV, rel=1e-12)


def test_mini_model_mw_matches_real_ufo_pattern():
    value = evaluate_pdg_mass(MINI_MODEL_DIR, 24)
    assert value == pytest.approx(EXPECTED_MW_GEV, rel=1e-12)


def test_unsupported_expression_fails_closed():
    with pytest.raises(UnsupportedExpression):
        evaluate_pdg_mass(MINI_MODEL_DIR, 999)


def test_unknown_pdg_fails_closed():
    with pytest.raises(UnsupportedExpression):
        evaluate_pdg_mass(MINI_MODEL_DIR, 123456789)


def test_patch_missing_mass_inserts_and_is_idempotent(tmp_path):
    value = evaluate_pdg_mass(REAL_MODEL_DIR, 24, MISSING_PDG24_CARD)
    out = tmp_path / 'patched.dat'
    changed_first = patch_missing_mass(MISSING_PDG24_CARD, 24, value, out)
    assert changed_first is True
    assert mass_block_has_pdg(out, 24)

    out2 = tmp_path / 'patched_again.dat'
    changed_second = patch_missing_mass(out, 24, value, out2)
    assert changed_second is False
    assert out.read_text(encoding='utf-8') == out2.read_text(encoding='utf-8')


def test_patch_missing_mass_does_not_touch_gc90_or_other_blocks():
    text_before = MISSING_PDG24_CARD.read_text(encoding='utf-8')
    assert 'ctauh2' in text_before  # sanity: fixture is the real generated card
