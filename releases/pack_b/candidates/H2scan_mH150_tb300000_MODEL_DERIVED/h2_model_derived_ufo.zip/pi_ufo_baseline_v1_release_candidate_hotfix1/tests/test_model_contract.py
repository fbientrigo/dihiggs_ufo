import math
import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from model_utils import PACK_KIND, alignment_coupling, compute_ufo_default_vev, load_ufo_inventory, normalize_point, pi_fixed_coupling, read_config, total_width_from_ctau

class ContractTests(unittest.TestCase):
    def test_inventory(self):
        inv = load_ufo_inventory()
        self.assertIn(9000006, inv['particle_pdgs'])
        self.assertEqual(len(inv['h2_vertices']), 2)
        self.assertEqual(inv['parameters'], 105 if PACK_KIND == 'A' else 106)
        self.assertEqual(inv['orders'], 4 if PACK_KIND == 'A' else 5)
        self.assertEqual(inv['h2_pdg'], 9000006)
        if PACK_KIND == 'A':
            self.assertEqual(inv['gc90']['value'], '8*complex(0,1)*Mh2**2/vev')
            self.assertEqual(inv['gc90']['order'], {'QED': -1})
        else:
            self.assertEqual(inv['gc90']['value'], 'complex(0,1)*GHphiphi')
            self.assertEqual(inv['gc90']['order'], {'NP': 1})

    def test_pi_formula(self):
        v = compute_ufo_default_vev()
        for m in (100.0, 200.0, 250.0):
            self.assertAlmostEqual(pi_fixed_coupling(m, v), 8*m*m/v, places=12)

    def test_lifetime(self):
        for ct in (1.0, 5.1, 100.0):
            width = total_width_from_ctau(ct)
            self.assertAlmostEqual(width*ct, 1.973269804e-13, places=25)

    def test_default_point(self):
        p = normalize_point(read_config(ROOT/'points/point_000001.yaml'))
        self.assertAlmostEqual(sum(p['branching_ratios'].values()), 1.0, places=12)
        self.assertAlmostEqual(p['ctau_m_for_historical_ufo'], p['ctau_mm']/1000.0, places=16)
        self.assertAlmostEqual(sum(p['partial_widths_GeV'].values()), p['total_width_GeV'], places=25)
        self.assertAlmostEqual(p['ghphiphi_GeV'], pi_fixed_coupling(p['mphi_GeV'], p['vev_GeV']), places=12)

    @unittest.skipIf(PACK_KIND == 'A', 'Pack B only')
    def test_free_coupling_exact(self):
        p = normalize_point(read_config(ROOT/'points/point_free_000001.yaml'))
        self.assertEqual(p['ghphiphi_GeV'], 100.0)

    @unittest.skipIf(PACK_KIND == 'A', 'Pack B only')
    def test_alignment_formula(self):
        v = compute_ufo_default_vev()
        self.assertAlmostEqual(alignment_coupling(125.0, 200.0, 40000.0, v), 125.0**2/v, places=12)

if __name__ == '__main__':
    unittest.main()
