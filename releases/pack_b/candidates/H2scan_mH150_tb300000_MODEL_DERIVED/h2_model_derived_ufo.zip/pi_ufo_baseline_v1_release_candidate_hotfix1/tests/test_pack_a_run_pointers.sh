#!/usr/bin/env bash
# Focused regression test for the hotfix1 .last_run/.last_reproduce pointer
# fix: exercises bin/lib/common.sh, status.sh, results.sh helper functions
# directly against synthetic run directories. Requires no MadGraph/Python
# toolchain. Run with: bash tests/test_pack_a_run_pointers.sh
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACK_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# shellcheck source=../bin/lib/common.sh
source "$PACK_ROOT/bin/lib/common.sh"
# shellcheck source=../bin/lib/status.sh
source "$PACK_ROOT/bin/lib/status.sh"
# shellcheck source=../bin/lib/results.sh
source "$PACK_ROOT/bin/lib/results.sh"

fail=0
pass_count=0
fail_count=0

check() {
  local desc="$1" expected="$2" actual="$3"
  if [[ "$expected" == "$actual" ]]; then
    echo "PASS: $desc"
    pass_count=$((pass_count + 1))
  else
    echo "FAIL: $desc (expected [$expected], got [$actual])"
    fail_count=$((fail_count + 1))
    fail=1
  fi
}

check_rc() {
  local desc="$1" expected_rc="$2" actual_rc="$3"
  if [[ "$expected_rc" == "$actual_rc" ]]; then
    echo "PASS: $desc (exit $actual_rc)"
    pass_count=$((pass_count + 1))
  else
    echo "FAIL: $desc (expected exit $expected_rc, got $actual_rc)"
    fail_count=$((fail_count + 1))
    fail=1
  fi
}

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

# --- pack_a_first_lhe ---
mkdir -p "$WORK/no_events_dir"
out="$(pack_a_first_lhe "$WORK/no_events_dir")"
check "first_lhe: missing events/ dir does not crash, returns empty" "" "$out"

mkdir -p "$WORK/empty_events/events"
out="$(pack_a_first_lhe "$WORK/empty_events")"
check "first_lhe: empty events/ dir returns empty" "" "$out"

mkdir -p "$WORK/has_lhe/events"
: > "$WORK/has_lhe/events/events.lhe.gz"
out="$(pack_a_first_lhe "$WORK/has_lhe")"
check "first_lhe: finds *.lhe.gz" "$WORK/has_lhe/events/events.lhe.gz" "$out"

# --- pack_a_is_physical_run ---
pack_a_is_physical_run "$WORK/does_not_exist" && r=0 || r=$?
check_rc "is_physical_run: nonexistent dir -> false" 1 "${r:-0}"

pack_a_is_physical_run "$WORK/no_events_dir" && r=0 || r=$?
check_rc "is_physical_run: no command.txt, no events -> false" 1 "${r:-0}"

mkdir -p "$WORK/no_lhe/events"
: > "$WORK/no_lhe/command.txt"
pack_a_is_physical_run "$WORK/no_lhe" && r=0 || r=$?
check_rc "is_physical_run: command.txt but no LHE -> false" 1 "${r:-0}"

mkdir -p "$WORK/valid_run/events"
: > "$WORK/valid_run/command.txt"
: > "$WORK/valid_run/events/events.lhe.gz"
pack_a_is_physical_run "$WORK/valid_run" && r=0 || r=$?
check_rc "is_physical_run: command.txt + LHE -> true" 0 "${r:-1}"

# --- pack_a_atomic_write_pointer ---
mkdir -p "$WORK/ptrdir"
pack_a_atomic_write_pointer "$WORK/ptrdir/.last_run" "$WORK/valid_run"
out="$(cat "$WORK/ptrdir/.last_run")"
check "atomic_write_pointer: value written correctly" "$WORK/valid_run" "$out"
leftover="$(find "$WORK/ptrdir" -maxdepth 1 -name '.pointer.*' 2>/dev/null | wc -l | tr -d ' ')"
check "atomic_write_pointer: no leftover temp file" "0" "$leftover"

# --- pack_a_find_last_run: explicit pointer wins ---
mkdir -p "$WORK/pack1/runs"
: > "$WORK/pack1/runs/.last_run"
echo "$WORK/valid_run" > "$WORK/pack1/runs/.last_run"
PACK_ROOT="$WORK/pack1"
out="$(pack_a_find_last_run)"
check "find_last_run: honors explicit .last_run pointer" "$WORK/valid_run" "$out"

# --- pack_a_find_last_run: legacy fallback skips reproduce-wrapper dirs ---
mkdir -p "$WORK/pack2/runs/20260101T000000Z_reproduce_seed12345"
mkdir -p "$WORK/pack2/runs/20260101T000000Z_seed12345/events"
: > "$WORK/pack2/runs/20260101T000000Z_seed12345/command.txt"
: > "$WORK/pack2/runs/20260101T000000Z_seed12345/events/events.lhe.gz"
PACK_ROOT="$WORK/pack2"
out="$(pack_a_find_last_run)"
check "find_last_run: legacy fallback skips wrapper dir, finds physical run" "$WORK/pack2/runs/20260101T000000Z_seed12345" "$out"

# --- status/results: no runs at all ---
mkdir -p "$WORK/pack3/runs"
PACK_ROOT="$WORK/pack3"
out="$(pack_a_cmd_status 2>&1)"; rc=$?
check_rc "status: no runs -> exit 0 (informational)" 0 "$rc"
[[ "$out" == *"No Pack A runs found"* ]] && echo "PASS: status message mentions no runs" && pass_count=$((pass_count+1)) || { echo "FAIL: status message wrong: $out"; fail_count=$((fail_count+1)); fail=1; }

# --- status/results: stale pointer ---
mkdir -p "$WORK/pack4/runs"
echo "$WORK/does_not_exist" > "$WORK/pack4/runs/.last_run"
PACK_ROOT="$WORK/pack4"
pack_a_cmd_status >/dev/null 2>&1 && rc=0 || rc=$?
check_rc "status: stale .last_run -> deliberate nonzero exit, no crash" 21 "$rc"
pack_a_cmd_results >/dev/null 2>&1 && rc=0 || rc=$?
check_rc "results: stale .last_run -> deliberate nonzero exit, no crash" 21 "$rc"

# --- status/results: pointer to dir without events/ (the confirmed defect shape) ---
mkdir -p "$WORK/pack5/runs/wrapper_dir"
echo "$WORK/pack5/runs/wrapper_dir" > "$WORK/pack5/runs/.last_run"
PACK_ROOT="$WORK/pack5"
pack_a_cmd_status >/dev/null 2>&1 && rc=0 || rc=$?
check_rc "status: pointer to dir without events/ -> deliberate nonzero exit, no crash" 21 "$rc"
pack_a_cmd_results >/dev/null 2>&1 && rc=0 || rc=$?
check_rc "results: pointer to dir without events/ -> deliberate nonzero exit, no crash" 21 "$rc"

# --- status/results: pointer to a valid physical run ---
mkdir -p "$WORK/pack6/runs"
echo "$WORK/valid_run" > "$WORK/pack6/runs/.last_run"
PACK_ROOT="$WORK/pack6"
pack_a_cmd_status >/dev/null 2>&1 && rc=0 || rc=$?
check_rc "status: pointer to valid physical run -> exit 0" 0 "$rc"
pack_a_cmd_results >/dev/null 2>&1 && rc=0 || rc=$?
check_rc "results: pointer to valid physical run -> exit 0" 0 "$rc"

echo
echo "pack_a pointer regression: $pass_count passed, $fail_count failed"
exit "$fail"
