import copy
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from model_utils import normalize_point, read_config

class InvalidPointTests(unittest.TestCase):
    def setUp(self):
        self.base=read_config(ROOT/'points/point_000001.yaml')
    def assertInvalid(self,data):
        with self.assertRaises(Exception): normalize_point(data)
    def test_negative_br(self):
        x=copy.deepcopy(self.base); x['branching_ratios']['bb']=-0.1; self.assertInvalid(x)
    def test_bad_sum(self):
        x=copy.deepcopy(self.base); x['branching_ratios']['bb']=0.4; self.assertInvalid(x)
    def test_unknown_channel(self):
        x=copy.deepcopy(self.base); x['branching_ratios']['invisible']=0.0; self.assertInvalid(x)
    def test_closed_channel(self):
        x=copy.deepcopy(self.base); x['mphi_GeV']=100; x['branching_ratios']={'bb':0.5,'WW':0.5}; self.assertInvalid(x)
    def test_negative_ctau(self):
        x=copy.deepcopy(self.base); x['ctau_mm']=-1; self.assertInvalid(x)
if __name__=='__main__': unittest.main()
