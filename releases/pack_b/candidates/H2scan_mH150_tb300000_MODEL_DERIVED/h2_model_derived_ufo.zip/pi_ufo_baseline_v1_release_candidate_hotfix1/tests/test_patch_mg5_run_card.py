from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))

import re

import pytest
from patch_mg5_run_card import REQUIRED_FIELDS, parse_settings, patch_run_card

_FIELD_LINE_RE = re.compile(r'^\s*([^#!]+?)\s*=\s*([A-Za-z0-9_]+)(.*)$')

FIXTURE = Path(__file__).resolve().parent / 'fixtures' / 'run_card_mg5_generated.dat'
SOURCE_TEXT = FIXTURE.read_text(encoding='utf-8')

FULL_SETTINGS_TEXT = """
100 = nevents
12345 = iseed
1 = lpp1
1 = lpp2
6500.0 = ebeam1
6500.0 = ebeam2
0 = ickkw
0.0 = xqcut
"""


def test_real_mg5_card_has_no_ickkw_xqcut_by_default():
    # This is the exact condition that used to make the patcher fail: a
    # freshly generated ZERO_JET_ONLY run_card.dat has no Matching block.
    assert 'ickkw' not in SOURCE_TEXT
    assert 'xqcut' not in SOURCE_TEXT


def test_patch_succeeds_without_ickkw_xqcut_in_source():
    settings = parse_settings(FULL_SETTINGS_TEXT)
    patched = patch_run_card(SOURCE_TEXT, settings)
    assert '100 = nevents' in patched
    assert '12345 = iseed' in patched
    assert '1 = lpp1' in patched
    assert '1 = lpp2' in patched
    assert '6500.0 = ebeam1' in patched
    assert '6500.0 = ebeam2' in patched


def test_patch_is_idempotent():
    settings = parse_settings(FULL_SETTINGS_TEXT)
    once = patch_run_card(SOURCE_TEXT, settings)
    twice = patch_run_card(once, settings)
    assert once == twice


@pytest.mark.parametrize('missing_field', sorted(REQUIRED_FIELDS))
def test_patch_fails_when_required_field_absent_from_source(missing_field):
    settings = parse_settings(FULL_SETTINGS_TEXT)
    # Strip the corresponding line from the source card so the field truly
    # cannot be found, then confirm the patcher fails closed.
    def matches_field(line: str) -> bool:
        m = _FIELD_LINE_RE.match(line)
        return bool(m and m.group(2) == missing_field)

    lines = [line for line in SOURCE_TEXT.splitlines() if not matches_field(line)]
    stripped_source = '\n'.join(lines)
    with pytest.raises(SystemExit):
        patch_run_card(stripped_source, settings)


def test_ickkw_xqcut_missing_from_source_does_not_fail():
    settings = parse_settings(FULL_SETTINGS_TEXT)
    assert 'ickkw' not in SOURCE_TEXT and 'xqcut' not in SOURCE_TEXT
    patch_run_card(SOURCE_TEXT, settings)  # must not raise
