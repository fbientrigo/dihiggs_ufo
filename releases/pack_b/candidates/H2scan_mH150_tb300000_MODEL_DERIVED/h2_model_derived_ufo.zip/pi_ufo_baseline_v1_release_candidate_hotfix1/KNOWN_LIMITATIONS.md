# Known limitations

- Not a complete 2HDM UFO; no lambda1...lambda7, tan(beta), m12^2, or full mixing structure.
- 2HDMC is not executed for new points.
- The finite form factor is attached to the `ggH` vertex only; 1-jet/2-jet samples are blocked.
- The historical diphoton vertex and lifetime are not a self-consistent UV prediction.
- Phenomenological BR inputs do not constitute a UV completion.
- Pythia decay-table import, displaced lifetime propagation, FastJet, and DV+jets recast require external validation.
- MadGraph equivalence of Pack A and Pack B under `PI_FIXED` is pending.
- The global sign and factor of `i` are rule-of-Feynman conventions; the real coefficient is recorded separately.
- `decays.py` in the historical UFO was not regenerated after the v3 triscalar change and must not be used as authoritative production-decay physics.
