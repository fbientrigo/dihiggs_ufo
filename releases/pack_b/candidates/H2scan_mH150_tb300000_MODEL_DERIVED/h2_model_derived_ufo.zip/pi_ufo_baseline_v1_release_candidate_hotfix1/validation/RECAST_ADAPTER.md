# Recast adapter

The public/local DV+jets repository has site-specific build and command paths. This pack does not guess them.

Set a command template:

```bash
export RECAST_INPUT=/absolute/path/to/showered_events.hepmc
export RECAST_CMD='/path/to/recast_adapter --variant {variant} --input {input} --cutflow {output}'
scripts/run_recast_smoke.sh build/point_000001
```

The adapter must emit non-empty `cutflow_A.csv` and `cutflow_B.csv`. Preserve executable commit, patch hash, FastJet version, jet algorithm, LLP PDG, and all efficiency-map settings.
