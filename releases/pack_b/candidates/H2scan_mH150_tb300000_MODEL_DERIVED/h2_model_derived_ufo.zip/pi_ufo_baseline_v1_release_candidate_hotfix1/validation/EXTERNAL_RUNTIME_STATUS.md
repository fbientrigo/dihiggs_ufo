# External runtime status

| Layer | State |
|---|---|
| Safe ZIP extraction | PASS |
| Python compile/import | PASS |
| Point/card generation | PASS |
| Coupling/lifetime/BR tests | PASS |
| MadGraph import and Pack A LO smoke cross section | PASS_WITH_WARNINGS |
| Stable LLP in generated LHE | PASS |
| Pythia displaced decay | NOT RUN — OUT OF SCOPE |
| FastJet/recast A/B cutflow | NOT RUN — OUT OF SCOPE |
