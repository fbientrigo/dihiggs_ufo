# Addendum técnico — LLscalar_v3 UFO

Fecha: 2026-07-16

## Alcance y provenance

- El archivo recibido `UFO(3).zip` tiene SHA-256
  `9d5e7d75e177e8b0ae7e4719c955e0ec9cc8dc9f95a8617d1561f5811cffa97d`.
- Es byte-idéntico al archivo denominado `UFO(2).zip` en el entregable de auditoría.
- Los 14 fuentes activos de `LLscalar_v3_UFO` coinciden con el manifiesto del entregable.
- Por tanto, las conclusiones estáticas principales del entregable sí aplican al ZIP recibido.

## Conclusión científica confirmada

`LLscalar_v3_UFO` es un modelo simplificado HEFT para

```text
g g -> H* -> h2 h2
```

con `h2 -> gamma gamma` como única interacción de decaimiento implementada. No contiene el potencial 2HDM, `lambda1...lambda7`, `tan(beta)`, `m12^2`, mezcla Type-I ni un puente punto-a-punto con 2HDMC.

No es el UFO físico final del proyecto DV+jets. Puede utilizarse como candidato de plumbing o cinemática de producción, manteniendo `h2` estable en el LHE y realizando un handoff de decaimiento separado y explícito en Pythia.

## Corrección 1 — writer de param_card no validado

La afirmación de que el writer bundled puede emitir directamente la card por defecto no se sostiene en Python 3.

Comando reproducido:

```bash
python3 -B write_param_card.py
```

Resultado:

```text
NameError: name 'MZ' is not defined
```

La causa está en `write_param_card.py:119-137`: el código usa `exec()` dentro de una función y después `eval()` esperando que los nombres evaluados aparezcan en el scope local, comportamiento que no funciona como esperaba el writer antiguo bajo Python 3.

Estado corregido:

```text
BUNDLED_PARAM_CARD_WRITER: PY3_BROKEN
MADGRAPH_GENERATED_PARAM_CARD: PENDING
```

Esto no prueba que MadGraph no pueda importar el UFO: MadGraph posee su propio manejo de parámetros y debe probarse separadamente.

## Corrección 2 — el form factor no cubre muestras multijet de forma consistente

El form factor dinámico `GGHFF` está conectado sólo a:

```text
V_15: g g H -> VVS2FF1
```

Los vértices HEFT con gluones adicionales permanecen sin ese form factor:

```text
V_42: g g g H  -> VVVS1
V_43: g g g g H -> VVVVS1/VVVVS2/VVVVS3
```

Consecuencia:

- un smoke de 0 partones `g g -> H* -> h2 h2` es una prueba razonable del UFO;
- muestras de 1/2 partones y matching/merging no deben describirse como una implementación finita-masa coherente de la misma amplitud;
- para el primer recast físico/proxy, comenzar con 0 partones evita introducir esta inconsistencia;
- cualquier campaña 0/1/2 partones requiere una validación específica o una implementación loop-capable apropiada.

## Interfaces que deben corregirse antes del recast

### PDG

```text
UFO h2:       9000006
bootstrap previo: 9900035
```

El recast/Pythia debe configurarse explícitamente con PDG `9000006` o debe existir un remapeo documentado.

### Unidad de lifetime

El UFO define:

```text
Wh2 = 1.9732698e-16 / ctauh2
```

por lo que `ctauh2` está en metros. El scanner usa normalmente `ctau_mm`.

Conversión obligatoria:

```text
ctauh2_UFO_m = ctau_mm_2HDMC / 1000
```

Omitirla produce un error de factor 1000 en la vida propia.

### Acople de producción

El acople está hardcodeado:

```text
GC_90 = 8 i Mh2^2 / vev
```

No puede recibir `g_hHH` desde 2HDMC mediante `param_card.dat`. Para un puente real debe:

1. transformarse en un parámetro externo con convención y unidades explícitas; o
2. usarse sólo como proxy y reponderarse bajo hipótesis claramente declaradas.

La etiqueta `QED=-1` debe eliminarse o sustituirse por un orden NP/BSM no negativo en una versión adaptada.

### Width y decaimiento

`Wh2` es interno y no existe un `DECAY 9000006` externo editable. Para la cadena LLP:

- generar `h2` estable en MadGraph/LHE;
- proporcionar `decay.slha` y lifetime a Pythia;
- no usar el decay-chain histórico `h2 > a a` para una muestra desplazada, pues eso produce hijas ya presentes en el LHE y evita la propagación espacial del LLP.

## Inconsistencias confirmadas

- `Gamma(h2 -> gamma gamma) / Gamma_total(h2) ~= 1.17e4` en defaults (`Mh2=200 GeV`, `ctauh2=0.1 m`).
- `Decay_H[H -> h2 h2]` conserva la fórmula de v2 aunque v3 cambió `GC_90`.
- `h1` (PDG 9000005) está desconectado y no participa en ningún vértice.
- No existen decaimientos hadrónicos de `h2`; el UFO no puede crear directamente el DV multitrack.

## Uso recomendado

### Permitido ahora

```text
UFO_STATIC_AUDITED
SIMPLIFIED_HEFT_PRODUCTION_PROXY_CANDIDATE
ZERO_PARTON_SMOKE_CANDIDATE
```

### No permitido afirmar

```text
FULL_2HDM_UFO
2HDMC_MATCHED
PHYSICAL_2HDM_CROSS_SECTION
CONSISTENT_0_1_2_PARTON_MERGED_SAMPLE
DVJETS_DECAY_MODEL
UFO_IMPORT_VALIDATED
```

## Próxima ejecución mínima

1. Importar el source-only v3 en MadGraph 3.5.3.
2. Generar únicamente `g g > H > h2 h2` con `h2` estable.
3. Usar tres masas, empezando por un punto del rango local.
4. Conservar log, MG version, process definition, generated `param_card.dat`, cross section y LHE.
5. Confirmar PDG 9000006 y dos `h2` finales por evento.
6. Pasar el LHE por Pythia con un `decay.slha` externo y PDG 9000006.
7. Sólo después ejecutar el cutflow A/B.

Criterio de éxito inicial:

```text
MadGraph import PASS
0-parton output PASS
integration nonzero
LHE contains stable PDG 9000006 pair
Pythia produces displaced decays with configured external decay table
```
