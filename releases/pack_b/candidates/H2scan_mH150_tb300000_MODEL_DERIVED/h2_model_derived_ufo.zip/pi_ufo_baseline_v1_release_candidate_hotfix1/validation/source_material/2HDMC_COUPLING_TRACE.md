# 2HDMC coupling trace used for the Pack B analytical preset

Repository reference: `fbientrigo/dihiggs`, inspected snapshot `4d19bb97caa02340e1558ca8d32fc68bcbaf28e5`.

1. `dihiggs/src/PhysScanWithFixings.cpp`: `set_param_phys_lam1(M_H, m_phi, ...)`, then canonical `set_param_phys(M_H, m_phi, ...)`.
2. `2hdmc/src/THDM.cpp`, `set_param_phys`: reconstructs lambda1...lambda5 using squared physical masses, m12^2, alpha, beta, lambda6 and lambda7.
3. `get_param_higgs`: rotates generic lambdas into Higgs-basis Lambda/Z coefficients.
4. `get_qki`: defines the sin(beta-alpha)/cos(beta-alpha) mixing coefficients.
5. `get_coupling_hhh(1,2,2)`: returns the h1-h2-h2 Feynman-rule coupling.

In exact alignment the real dimension-one coefficient reduces to

```text
GHphiphi = (mh^2 + 2*mphi^2 - 2*Mbar2) / v
Mbar2 = m12^2 / (sin(beta)*cos(beta))
```

The Pack B preset stores this real coefficient. The UFO coupling uses `+i*GHphiphi`; a global sign is convention-dependent.
