# Scientific audit of the LL scalar UFO family

Labels: `UFO_STATIC_AUDITED`, `SIMPLIFIED_LLSCALAR_MODEL`, `NOT_FULL_2HDM`,
`NOT_RECAST_RESULT`, `NOT_EXCLUSION`

## 1. Executable model content

The v3 source loads under Python 3.12.13 and registers 45 particles, 105
parameters, 145 couplings, 169 vertices, 26 Lorentz structures, one form
factor, 13 decay tables, and four coupling orders. This is a Python/UFO static
load, not a MadGraph import validation.

Only two vertices contain `h2`:

| Vertex | UFO coupling | Purpose |
|---|---|---|
| `H h2 h2` | `GC_90 = 8 i Mh2^2/vev` | Pair production through an off-shell SM-like Higgs |
| `a a h2` | `GC_2 = -i Ah2` | Diphoton decay/effective interaction |

No vertex contains `h1`. It has a mass (`MP`), an external width (`WH1`) and
PDG 9000005, but is dynamically disconnected from this UFO.

## 2. Evolution of the variants

### SMplusDV to v2 FormFactor

The May 2021 historical model used external independent values for `Ah2` and
`Wh2`. The June 2021 v2 source:

- replaces external `Wh2` with external `ctauh2` and internal
  `Wh2 = 1.9732698e-16/ctauh2`;
- makes `Ah2` internal with value `1e-7 ee^2 vev/(32 pi)`;
- changes the `ggH` Lorentz structure from the fixed HEFT tensor to a dynamic
  `GGHFF` form factor;
- adds top and bottom loop terms dependent on the partonic invariant mass;
- retains the same particle and main interaction inventory.

The constant in `Wh2` is hbar*c in GeV*m, so the code implies that `ctauh2` is
in metres. This unit is inferred from the formula and historical intention; the
SLHA block does not encode a unit.

### v2 to v3

`GC_90` changes from `2 i vev` to `8 i Mh2^2/vev`. The old line is left
commented immediately above the new line. All other active physics sources are
identical, aside from a comment in `lorentz.py`.

This is strong evidence that v3 is a manual post-export edit of the v2 UFO, not
a fresh FeynRules export:

- the retained log is named `23-06-21_LLscalar_v2_UFO.log`;
- v2 and v3 share the same generated headers and timestamps;
- the log reports the same 169 vertices and 145 couplings;
- `decays.py` was not regenerated for the new triscalar coupling;
- the old `GC_90` is preserved as a comment in v3.

## 3. Production coupling and expected differential

For the restricted process `g g > H > h2 h2`, v2 and v3 differ only in the
triscalar vertex. If MadGraph selects the same single diagram and identical
cards, the expected ratios are:

| `Mh2` (GeV) | `g_v3/g_v2` | Expected `sigma_v3/sigma_v2` |
|---:|---:|---:|
| 100 | 0.659799 | 0.435334 |
| 200 | 2.639194 | 6.965345 |
| 250 | 4.123741 | 17.005237 |

These are analytic expectations, not generated cross sections. They still need
the MadGraph differential test.

The production amplitude is determined by PDFs/scales and collider setup,
the dynamic `ggH` top+bottom loop form factor, the off-shell `H` propagator,
and `GC_90`. It is not determined by `lambda1...lambda7`, `tan(beta)`, or
`m12^2`; those parameters do not exist in this UFO.

## 4. Dynamic ggH form factor

`GGHFF` uses `s = 2 P(-1,1).P(-1,2)` and sums top and bottom loop terms. The
piecewise scalar integral uses an `asin` branch below threshold and a complex
logarithmic branch above threshold. A `regfunction` replaces exactly zero by
`1e-11` to avoid division by zero.

Scientific caveats:

- it is an effective LO construction based on HEFT with a custom finite-mass
  correction, not a complete NLO 2HDM calculation;
- the zero-invariant regulator is numerical rather than a documented physical
  prescription;
- branch/threshold behavior and MadGraph code generation remain unvalidated in
  this environment;
- no independent comparison against a known loop amplitude is included.

## 5. Width and decay consistency

The total propagator width of `h2` is controlled only by `ctauh2`:

```text
Gamma_total(h2) = 1.9732698e-16 GeV*m / ctauh2[m].
```

The only `h2` partial decay in `decays.py` is:

```text
Gamma(h2 -> gamma gamma) = Ah2^2 Mh2^3/(64 pi).
```

`Ah2` is not derived from `ctauh2`. At the default `ctauh2=0.1 m`, the total
width is `1.97327e-15 GeV`. With the default internal `Ah2` and `Mh2=200 GeV`,
the diphoton partial width is approximately `2.30403e-11 GeV`, implying the
nonsensical ratio `Gamma_gamma_gamma/Gamma_total ~= 1.17e4`.

Therefore the lifetime and diphoton decay coupling are not internally
consistent. The model can set a propagator lifetime or describe an arbitrary
diphoton effective vertex, but cannot be treated as predicting a physical BR
for both defaults simultaneously. The bare factor `1e-7` in `Ah2` must also
carry an undocumented inverse-mass convention for the effective operator to
have the expected dimension.

There is a second v3 inconsistency: `Decay_H` retains the v2 formula for
`H -> h2 h2`, proportional to `vev^2/(8 pi MH)` times phase space. That formula
corresponds to the v2 coupling `2 vev`, not the v3 coupling
`8 Mh2^2/vev`. The external `WH=0.00407 GeV` in the default card is not updated
from either partial-width formula. For the intended off-shell samples with
`Mh2 > MH/2`, the on-shell channel is closed, but the stale decay expression is
still evidence that v3 was not regenerated as a coherent UFO.

## 6. Coupling-order warning

`GC_90` is tagged `QED=-1`. FeynRules explicitly reports a non-positive
interaction order warning. MadGraph may still include the vertex in an
unrestricted process, but coupling-order filters and automatic order inference
must not be trusted until the exact import/generation test is run. The
production chain otherwise contains `HIG=1` for `ggH` and `HIW=1` for the
photon effective interactions.

## 7. Backup files

The active `parameters.py` differs from `parameters.py~` by parentheses in
`Ah2`:

```text
backup: 1e-7*ee^2*vev/32*pi
active: 1e-7*ee^2*vev/(32*pi)
```

This changes the value by a factor of `pi^2`; the active file is unambiguous
and is the authority. The active `function_library.py` also adds the helper
functions used by the dynamic form factor relative to its backup.

## 8. Suitability for the current DV+jets recast

This UFO has no `h2` coupling to quarks, gluons, or other hadronic states. Its
only decay is `h2 -> gamma gamma`. It therefore cannot directly provide the
multi-track displaced hadronic vertex required by a DV+jets analysis.

It can be used, subject to a successful MadGraph test, as a simplified
production-kinematics proxy with stable `h2`. A separate, explicitly documented
decay handoff would then be required. Such a handoff would define a different
physics model and is outside this audit.

## 9. Historical documentation versus executable content

The two-page May 2021 note is titled *Displaced di-photons at the LHC*. It
describes the process as exotic scalar-pair production through an off-shell SM
Higgs in an almost-inert 2HDM context. Its caption states that the 13 TeV
production cross section and `phi -> gamma gamma` branching ratio were taken
from an external reference, while the plotted decay probability used a
spherical-detector approximation.

The bundled `ReadMe` likewise calls the `AAh2` coefficient arbitrary and gives
the four-photon MadGraph command. These documents establish the intended
diphoton simplified-model use. They do not establish that the UFO contains the
2HDM potential or predicts its cross section and branching ratios; the
executable parameter and vertex inventories show that it does not.
