# MadGraph smoke-test report

## Result

Status: `BLOCKED`  
Applicable evidence label: `UFO_STATIC_AUDITED`  
Labels not earned: `UFO_IMPORT_VALIDATED`, `MADGRAPH_SMOKE_SAMPLE`

MadGraph5_aMC@NLO is not installed or exposed in this environment. No
`mg5_aMC` or `mg5` executable was found in `PATH`, `/opt`, or `/workspace`.
Per the audit scope, no large MadGraph stack was installed.

## Environment

- OS: Ubuntu 24.04.3 LTS, x86_64
- Kernel: Linux 6.12.47
- Python: 3.12.13
- MadGraph: unavailable

## Checks completed without MadGraph

The cache-free source copy contains 14 active `.py` files. All 14 parse with
Python's AST. Direct module loading under Python 3.12.13 succeeds and registers:

- 45 particles;
- 105 parameters;
- 145 couplings;
- 169 vertices;
- 26 Lorentz structures;
- one form factor;
- 13 decay objects;
- four coupling orders.

The direct `__init__.py` load also succeeds. This establishes basic source
integrity only; it does not test MadGraph's UFO parser, form-factor code
generation, negative coupling order, matrix-element construction, integration,
or event generation.

## Reproducible blocked command

```bash
command -v mg5_aMC
command -v mg5
find /opt /workspace -type f -name mg5_aMC -o -name mg5
```

All searches returned no executable.

## Prepared smoke card

`cards/proc_card_smoke.dat` contains the requested import, displays, restricted
production process, and output command. Run it from this audit directory with a
known MadGraph installation:

```bash
<MG5_DIR>/bin/mg5_aMC cards/proc_card_smoke.dat \
  2>&1 | tee logs/madgraph_smoke.log
```

The first run must keep `h2` stable. Event generation, cross-section extraction,
and LHE PDG inspection remain pending.

## Differential test status

No v2/v3 cross sections were generated. `results/cross_section_smoke.csv`
records the planned masses and analytic coupling-ratio expectations with an
explicit `BLOCKED_MG_UNAVAILABLE` status. Those ratios are not simulation
results.

