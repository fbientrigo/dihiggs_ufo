# Model card: LLscalar_v3_UFO

## Identity

- Status: `CANONICAL_CANDIDATE`
- Evidence label: `UFO_STATIC_AUDITED`
- Physics labels: `SIMPLIFIED_LLSCALAR_MODEL`, `NOT_FULL_2HDM`
- Provenance archive: nested `UFO/LLscalar_v3_UFO.zip`
- Archive SHA-256: `cf070792c73e74629ac26e2d1008a662a341a2fff1b8e94b9caf6ce2d9cf312e`
- Base: FeynRules Higgs Effective Couplings/HEFT model, reported model version
  1.4.7
- Export log: FeynRules 2.3.43, Mathematica 12.1.1, 23 June 2021
- Intended process: `g g > H > h2 h2`, historically followed by
  `h2 > a a`

## New scalar states

| UFO name | PDG | Mass | Width | Executable role |
|---|---:|---|---|---|
| `H` | 25 | external `MH`, default 125 GeV | external `WH`, default 0.00407 GeV | SM-like Higgs mediator, potentially off shell |
| `h1` | 9000005 | external `MP`, default 120 GeV | external `WH1` | Disconnected placeholder; no vertices |
| `h2` | 9000006 | external `Mh2`, default 200 GeV | internal `Wh2` | Long-lived scalar produced in pairs and coupled to two photons |

## Parameters relevant to the extension

| Parameter | Nature | SLHA location | Default | Meaning |
|---|---|---|---:|---|
| `Mh2` | external | `MASS 9000006` | 200 | `h2` mass in GeV |
| `ctauh2` | external | `FRBlock 2` | 0.1 | Proper decay length, inferred to be metres |
| `Wh2` | internal | not emitted as `DECAY 9000006` | `1.9732698e-16/ctauh2` | Total propagator width in GeV |
| `Ah2` | internal | none | `1e-7 ee^2 vev/(32 pi)` | Arbitrary effective diphoton coupling; unit convention undocumented |
| `MP` | external | `MASS 9000005` | 120 | Disconnected `h1` mass |
| `WH1` | external | `DECAY 9000005` | 0.00575308848 | Disconnected `h1` width |

The remaining external parameters are HEFT/SM inputs: `aEWM1`, `Gf`, `aS`,
Cabibbo angle, fermion Yukawa masses, particle masses, and the external widths
of the top, W, Z, `H`, and `h1`.

## New interactions

| Interaction | Coupling |
|---|---|
| `H h2 h2` | `8 i Mh2^2/vev`, tagged `QED=-1` |
| `a a h2` | `-i Ah2`, tagged `HIW=1` |
| modified `g g H` | HEFT coefficient multiplied by a dynamic top+bottom form factor, tagged `HIG=1` |

The v3 triscalar has mass dimension one. Its mass dependence is a hard-coded
simplified-model choice, not a derived 2HDM coupling.

## Decays

- The only decay table entry for `h2` is `h2 -> gamma gamma`.
- The total `h2` width is independently fixed by `ctauh2`.
- The resulting partial width and total width are not normalized to one another.
- `Decay_H[H -> h2 h2]` still corresponds to the v2 triscalar and is stale in
  v3.

## Approximations and warnings

- Simplified LO scalar model; not a complete 2HDM UFO.
- No `lambda1...lambda7`, `tan(beta)`, mixing angles, Yukawa type, or `m12^2`.
- No point-by-point bridge to 2HDMC.
- Dynamic custom loop form factor not validated here with MadGraph or an
  independent amplitude.
- FeynRules warning: non-positive interaction order for `GC_90`.
- `h1` is disconnected.
- `h2` has no hadronic decay, so this is not directly a DV+jets model.
- v3 appears to be a manual edit on v2, not a fresh FeynRules export.

## Explicit answers

1. **Simplified or complete 2HDM?** Simplified LL-scalar model built on HEFT;
   not a complete 2HDM.
2. **Can it directly receive `lambda1...lambda7`, `tan(beta)`, and `m12^2`?**
   No. Those inputs and their relations are absent.
3. **What determines the production cross section?** Collider/PDF/scale cards,
   the custom top+bottom `ggH` form factor, the off-shell `H` propagator, and
   the hard-coded `Hh2h2` coupling. It is not a 2HDMC cross section.
4. **What determines the lifetime?** `ctauh2` alone through
   `Wh2 = hbar*c/ctauh2`, with `ctauh2` inferred in metres.
5. **What determines `gamma gamma` decay?** The fixed internal `Ah2` effective
   coupling and `Mh2`.
6. **Are lifetime and `gamma gamma` internally consistent?** No. They are
   independent and the defaults imply a partial width larger than the total.
7. **Can it be used for DV+jets without an external decay handoff?** No. It has
   no hadronic `h2` decay or multi-track displaced vertex.
8. **What exactly is v3?** The v2 FormFactor UFO with the executable
   `Hh2h2` coupling manually changed from `2 i vev` to
   `8 i Mh2^2/vev`; the remaining physics source is unchanged.

Confidence: 97% for the static/source conclusions; MadGraph runtime
compatibility remains unmeasured.

