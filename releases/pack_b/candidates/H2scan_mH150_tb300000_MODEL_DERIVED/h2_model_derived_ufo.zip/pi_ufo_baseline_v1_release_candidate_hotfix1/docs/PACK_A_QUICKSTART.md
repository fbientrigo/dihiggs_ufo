# Pack A Quickstart

## Unzip and verify

```bash
unzip pi_ufo_baseline_v1_release_candidate.zip
cd pi_ufo_baseline_v1_release_candidate
sha256sum -c checksums.sha256
```

## From inside the pack

```bash
bin/pack-a preflight
bin/pack-a run
bin/pack-a status
bin/pack-a results
bin/pack-a reproduce
bin/pack-a clean --confirm
```

## From outside the pack (no `cd` required)

```bash
/path/to/pi_ufo_baseline_v1_release_candidate/bin/pack-a preflight
/path/to/pi_ufo_baseline_v1_release_candidate/bin/pack-a run
```

## With an explicit MadGraph binary

```bash
MG5_BIN="$HOME/.local/mg5amcnlo/3.5.3/bin/mg5_aMC" bin/pack-a preflight
MG5_BIN="$HOME/.local/mg5amcnlo/3.5.3/bin/mg5_aMC" bin/pack-a run
```

## With an explicit Python environment

```bash
PACK_A_VENV="$HOME/atlas_dihiggs/llp_recast/.venv" bin/pack-a preflight
PACK_A_VENV="$HOME/atlas_dihiggs/llp_recast/.venv" bin/pack-a run
```

## Optional seed-67890 cross-check

```bash
bin/pack-a run --seed 67890
bin/pack-a reproduce --seed 67890
```

## `.last_run` vs `.last_reproduce`

`runs/.last_run` always identifies the most recent *physical* run — the
directory that actually contains `events/`, `command.txt`,
`environment.json`, `run.log`, and `manifest.json` — whether it was produced
by `run` or by `reproduce` (in which case it is the nested generation
directory under `reproduce`'s own clean extraction). `runs/.last_reproduce`
separately records the reproduce-wrapper directory itself and is never used
by `status`/`results` to locate evidence. If `.last_run` is missing, stale,
or points at an incomplete directory, `status`/`results` print an explicit
`BLOCKED:` message and exit nonzero rather than crashing or truncating
output.

## Never source it

```bash
# correct: runs as its own process, exit status is real, your shell is untouched
bin/pack-a preflight || rc=$?
echo "shell still alive: $rc"

# wrong: do not do this
# source bin/pack-a preflight
```

See `docs/PACK_A_TROUBLESHOOTING.md` if any of the above fails, and
`docs/PACK_A_SCIENTIFIC_SCOPE.md` before drawing conclusions from `results`.
