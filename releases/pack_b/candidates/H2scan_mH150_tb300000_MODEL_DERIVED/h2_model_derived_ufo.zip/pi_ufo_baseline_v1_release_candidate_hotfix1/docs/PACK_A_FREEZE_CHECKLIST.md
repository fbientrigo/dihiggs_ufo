# Pack A Freeze Checklist

This checklist is for a **future, separate freeze mission**. It is not
executed here, and this release does not authorize a freeze. Every item
below must be independently re-verified by that future mission before any
freeze decision.

```text
[ ] hash of the Sol candidate (df369...) reverified against its declared value
[ ] eight physics-invariant files byte-identical to pi_ufo_baseline_v1.zip
[ ] release candidate ZIP hash computed and recorded externally (not inside the ZIP)
[ ] release candidate ZIP extracts cleanly on a second, independent machine
[ ] preflight passes on that independent extraction
[ ] reproduce passes (seed 12345) on that independent extraction
[ ] reproduce passes (seed 67890) on that independent extraction, if run
[ ] cross-section compatibility at 3-sigma confirmed against Sol reference values
[ ] LHE invariants (event count, LLP count, mass, mothers, 4-momentum) confirmed
[ ] no physics override flags accepted by bin/pack-a run/reproduce
[ ] no Pythia, MadSpin, Pack AA, Pack B, or recast execution anywhere in this pack
[ ] diff against the Sol candidate contains zero physics-file content changes
[ ] manifest.json and checksums.sha256 internally consistent (sha256sum -c passes)
[ ] all JSON in the pack parses with a real parser
[ ] clean --confirm tested: rejects without --confirm, removes only interface-generated runs/
[ ] reproduce -> status/results resolves the nested physical run (hotfix1 regression) reverified independently
[ ] no absolute machine-specific paths in any distributed manifest
[ ] documentation (Sol + Luna) reviewed for consistency with the frozen artifact
[ ] explicit sign-off recorded from whoever authorizes the freeze
```

Do not mark any item above as complete from this mission's evidence alone;
this file exists to be filled in by the freeze mission itself.

FREEZE_STATUS=FROZEN
