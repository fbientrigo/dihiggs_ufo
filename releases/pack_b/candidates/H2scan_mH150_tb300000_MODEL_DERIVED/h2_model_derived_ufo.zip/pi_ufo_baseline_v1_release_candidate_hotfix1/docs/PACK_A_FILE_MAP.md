# Pack A File Map

## Physics-invariant files — authority, byte-identical to the PI original

These eight files must never differ from `pi_ufo_baseline_v1.zip`
(sha256 `632bf77818c84118fa707ad058cb655b90d018a394290cf565ab9d50f2db08cd`).
`bin/pack-a preflight` verifies all eight on every run.

```text
model/LLscalar_v3_UFO_runtime/couplings.py
model/LLscalar_v3_UFO_runtime/vertices.py
model/LLscalar_v3_UFO_runtime/particles.py
model/LLscalar_v3_UFO_runtime/parameters.py
model/LLscalar_v3_UFO_runtime/decays.py
model/LLscalar_v3_UFO_runtime/form_factors.py
model/LLscalar_v3_UFO_runtime/lorentz.py
model/LLscalar_v3_UFO_runtime/coupling_orders.py
```

`vendor/LLscalar_v3_UFO_original/` — the PI's own original UFO copy, kept for
provenance comparison; not imported by any script at runtime.

## Operational scripts — authority: Sol (physics-adjacent, validated)

```text
scripts/build_point.py            point/card generation
scripts/run_mg5_smoke.sh          MadGraph invocation; Sol-corrected MadeEvent sequence
scripts/patch_mg5_run_card.py     run_card field substitution
scripts/materialize_internal_masses.py   independent mass cross-check / fallback patch
scripts/inspect_lhe.py            LHE stability report (events, final/nonfinal LLP counts)
scripts/extract_mg5_cross_section.py   cross-section parsing from MG5 logs
scripts/model_utils.py            shared card-writing helpers
scripts/validate_point.py, scripts/make_param_card.py, scripts/make_decay_slha.py,
scripts/pack_constants.py, scripts/check_coupling_scaling.py, scripts/run_static_tests.py
```

Do not edit these to "fix" portability or ergonomics issues; they carry the
validated physics/runtime contract. Luna's layer wraps them.

## Operator interface — authority: Luna (this release)

```text
bin/pack-a                        public entry point
bin/lib/common.sh                 logging/helpers
bin/lib/resolve.sh                Python/MadGraph resolution
bin/lib/preflight.sh              preflight checks
bin/lib/run.sh                    run (+ shared generation core)
bin/lib/reproduce.sh              clean-extraction reproduction
bin/lib/status.sh, bin/lib/results.sh, bin/lib/clean.sh
bin/lib/lhe_invariants.py         read-only LHE invariant/cross-section check
points/A_PI_NATIVE_200_seed67890.yaml   optional Sol-validated alt-seed config (physics identical to A_PI_NATIVE_200.yaml)
```

## Cards/templates

```text
cards/README.md, cards/proc_card_zerojet.dat, cards/run_card_smoke.dat,
cards/pythia8.template.cmnd   (template only — Pythia is never invoked by this interface)
```

## Documentation — Sol (scientific authority)

```text
PACK_A_SOL_SCIENTIFIC_VALIDATION.md      workspace root
PACK_A_MADEVENT_INTERACTION_TRACE.md     workspace root
PACK_A_REPRODUCIBILITY_MATRIX.json       workspace root
PACK_A_SCIENTIFIC_STATUS.json            workspace root
PATCH_PACK_A_SOL_VALIDATION.diff         workspace root
validation/source_material/*            in-pack scientific evidence and traces
```

## Documentation — Luna (this release, ergonomics)

```text
README_PACK_A.md
docs/PACK_A_QUICKSTART.md
docs/PACK_A_SCIENTIFIC_SCOPE.md
docs/PACK_A_TROUBLESHOOTING.md
docs/PACK_A_FILE_MAP.md          (this file)
docs/PACK_A_FREEZE_CHECKLIST.md
```

## Manifests

```text
manifest.json          in-pack file inventory + hashes, regenerated for this candidate
checksums.sha256        sha256sum -c compatible checksum list, regenerated for this candidate
```

Workspace-root sidecar (not inside the ZIP; describes the ZIP from outside,
avoiding the self-referential-hash problem):

```text
PACK_A_RELEASE_CANDIDATE_MANIFEST.json
```

## Runtime evidence (generated, excluded from the shipped ZIP)

```text
runs/<timestamp>_seed<seed>[_label]/       created by `run`
runs/<timestamp>_reproduce_seed<seed>/     created by `reproduce`
```

Nothing under `runs/` is authoritative source; it is disposable evidence
subject to `bin/pack-a clean --confirm`.

## Historical / superseded, not part of this candidate's authority

```text
pi_ufo_baseline_v1_runtimefix.zip          superseded candidate (workspace root)
patches/python3_param_card_compat.patch    historical MG5 Python-3 compat patch, informational
CHANGELOG.md                               historical log, not updated by this release
```
