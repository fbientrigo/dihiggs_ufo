# Pack A Scientific Scope

This document restates Sol's scientific classification for the Luna
operator layer; it does not re-derive it. Authority: workspace-root
`PACK_A_SOL_SCIENTIFIC_VALIDATION.md`, `PACK_A_SCIENTIFIC_STATUS.json`,
`PACK_A_REPRODUCIBILITY_MATRIX.json`.

Scientific verdict: **`PASS_WITH_WARNINGS`**.
Cross-section classification: **`PACK_A_LO_SMOKE_XSEC`**.

## Allowed uses

```text
YES:
  baseline production regression
  generation of LHE with a stable LLP (h2, PDG 9000006)
  input to a future, separate Pack AA (Pythia/decay) stage
```

## Conditional uses

```text
CONDITIONAL:
  comparison of A vs B under PI_FIXED,
  only with an identical production/toolchain contract;
  this pack does not run Pack B and does not perform that comparison itself
```

## Forbidden uses

```text
NO:
  final 2HDM prediction
  physical branching-ratio prediction
  publishable production normalization
  final normalization of the recast
```

## Active scientific warnings (Sol)

- No LHAPDF installation was available; MG5 did not compute PDF systematics.
- Scale/PDF systematic uncertainties are absent.
- `GC_15` depends directly on `aS` while its QCD order is declared zero;
  automatic scale-uncertainty estimation can be wrong as a result.
- This MadGraph5_aMC@NLO 3.5.3 installation self-identifies as an unknown
  development build and warns against production use.
- Python 3.12 support is marked experimental by this MG5 build (still, prior
  reproductions completed successfully under 3.12 — see the Sol report).
- Only the zero-extra-parton sample exists; no matched/merged sample.

None of the above are operational blockers for Pack A native generation —
`bin/pack-a preflight` surfaces them as `WARN`/`INFO` rows, never `FAIL`.

## What Pack A explicitly is not

- Not Pack AA (no Pythia, no MadSpin, no h2 decay).
- Not Pack B (different coupling scheme; not built, not run here).
- Not a recast (no cutflow, no detector-level acceptance, no exclusion limit).
- Not frozen — see `docs/PACK_A_FREEZE_CHECKLIST.md`.
