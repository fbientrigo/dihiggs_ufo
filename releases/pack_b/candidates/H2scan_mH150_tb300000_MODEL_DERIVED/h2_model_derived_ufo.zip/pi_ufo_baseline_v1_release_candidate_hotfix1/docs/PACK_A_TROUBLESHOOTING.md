# Pack A Troubleshooting

## venv ausente / no venv found

`bin/pack-a` looks for an active `python3`, then `PACK_A_VENV`, then
`$HOME/atlas_dihiggs/llp_recast/.venv`, then
`$HOME/code/dihiggs_llp_recast/.venv`. If none has PyYAML, `preflight`
reports `python: FAIL` with the exact list tried. Fix: create/point to a
venv with `pip install PyYAML` and export `PACK_A_VENV=/path/to/venv`.

## `PACK_A_VENV` inválido

If `PACK_A_VENV` is set but `$PACK_A_VENV/bin/python3` is missing, not
executable, older than 3.9, or lacks PyYAML, the wrapper logs a `WARN` and
falls through to the next candidate — it does not hard-fail on an invalid
override alone. It only fails if every candidate in the priority list fails.

## `MG5_BIN` ausente

`preflight`/`run` report `madgraph: FAIL` with:
`export MG5_BIN=$HOME/.local/mg5amcnlo/3.5.3/bin/mg5_aMC`. Nothing is
downloaded or installed automatically.

## `MG5_BIN` no ejecutable

If `MG5_BIN` points at a non-executable or missing file, the wrapper logs a
`WARN` and falls through to `command -v mg5_aMC`, then `$MG5_HOME/bin/mg5_aMC`,
then the documented default path — it does not stop at the bad override.

## Versión de MG5 inesperada

`preflight` starts the resolved binary once (`printf 'quit\n' | mg5_aMC`)
and greps its banner for `VERSION 3.5.3`. If that string is absent, it warns
(does not block) that the toolchain may differ from the validated 3.5.3.

## PyYAML ausente

`preflight` reports `PyYAML: FAIL` naming the interpreter it tried. Install
into that interpreter's environment (`pip install PyYAML`) or point
`PACK_A_VENV` elsewhere.

## `MASS 24` ausente inicialmente

Expected. MadEvent derives PDG-24 (W) mass from internal UFO parameters; the
point writer never serializes it. `scripts/run_mg5_smoke.sh` answers the
MadEvent prompts with `0`, `update dependent`, `0`, which materializes it
during card review. See `PACK_A_MADEVENT_INTERACTION_TRACE.md`.

## Por qué no `update missing`

`update missing` is only valid inside the card-edit menu; sent at the
switch-selection prompt (as the older runtime-fix did) it is rejected, and
the actual materialization then happens implicitly via EOF's default `0`
triggering an automatic `update dependent`. That path works but depends on
an implicit fallback. The corrected, explicit sequence removes the rejected
command entirely. Full trace in `PACK_A_MADEVENT_INTERACTION_TRACE.md`.

## Warning de Python 3.12

MG5 3.5.3 marks 3.12 support "experimental" in its banner. `bin/pack-a`
surfaces this as a non-blocking `WARN` when the selected interpreter is
3.12.x — prior full reproductions (Sol's and this pack's) completed
successfully under 3.12.

## LHAPDF ausente

Expected and documented (see `docs/PACK_A_SCIENTIFIC_SCOPE.md`). MG5 logs
"No version of lhapdf. Can not run systematics computation" and proceeds;
this is why the cross section is classified `PACK_A_LO_SMOKE_XSEC` rather
than publishable.

## Shell cerrada o alterada por `source`/`set -e`

`bin/pack-a` must be **executed**, never `source`d. It is a normal script
with its own `set -Eeuo pipefail`; that only affects its own process. If you
`source` it, its `exit` calls will close your interactive shell. Verify with:

```bash
bin/pack-a preflight || rc=$?
echo "shell-still-alive rc=$rc"
```

## LHE ausente

`run`/`reproduce` fail with a clear message if no `unweighted_events.lhe(.gz)`
is found after MadEvent finishes; check `run.log` in the run directory for
the MadEvent-side cause (most often exit before `generate_events` completed).

## `run` con exit status distinto de cero

Check, in order: `<run_dir>/build_point.log`, then `<run_dir>/run.log`, then
`<run_dir>/exit_status.txt`. Every stage's log is preserved regardless of
outcome; nothing is overwritten by a later run.

## Mismatch de hash / manifest y checksums obsoletos

`preflight`'s `pack integrity` check runs `sha256sum -c checksums.sha256`.
A mismatch means either a file was edited after the manifest/checksums were
regenerated, or you are looking at a stale copy. Never "fix" this by
skipping the check — resolve which file is authoritative first.

## `status`/`results` after `reproduce` (hotfix1)

`reproduce` runs its canonical generation nested inside its own clean
extraction (`runs/<ts>_reproduce_seed<N>/clean_extraction/runs/...`). As of
hotfix1, `reproduce` promotes that nested generation directory to the outer
pack's `runs/.last_run` as soon as it is confirmed complete (has
`command.txt` and an LHE under `events/`), independent of whether the
subsequent Sol cross-section/LHE-invariant comparison passes. `status` and
`results` therefore resolve the same physical run after either `run` or
`reproduce`. The reproduce-wrapper directory is recorded separately in
`runs/.last_reproduce` and is never treated as a physical run.

## Stale or incomplete `.last_run` pointer

If `runs/.last_run` points at a directory that no longer exists, or at a
directory missing `command.txt` / any `*.lhe`/`*.lhe.gz` under `events/`,
`status` and `results` print an explicit `BLOCKED:` message naming the
resolved path and exit nonzero (21). They never run `find` against a
directory that may not exist and never promote an incomplete or failed run
to `.last_run` in the first place — `run` and `reproduce` only update the
pointer after confirming the target directory is a complete physical run.

## `py3_model.pkl` and `checksums.sha256`

`model/LLscalar_v3_UFO_runtime/py3_model.pkl` is the UFO model's own pickled
object cache; the model machinery rewrites it in place the first time it is
loaded under a given Python/pickle-protocol combination, then leaves it
stable on subsequent loads. It is intentionally excluded from
`checksums.sha256`/`manifest.json` (as of hotfix1) so that this expected,
environment-dependent one-time rewrite never registers as a pack-integrity
failure. The eight physics-invariant `.py` source files remain checked
byte-for-byte regardless (see `preflight`'s dedicated check); only this one
derived binary cache is excluded.

## Pythia/FastJet ausentes pero no requeridos

`preflight` reports these as `INFO`, never `FAIL`/`WARN`-with-blocking-intent.
Pack A native does not call either; their absence never affects `run`,
`reproduce`, `status`, or `results`.
