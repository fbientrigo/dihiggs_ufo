# External runtime status

| Layer | State |
|---|---|
| Safe ZIP extraction | PASS |
| Python compile/import | PASS |
| Point/card generation | PASS |
| Coupling/lifetime/BR tests | PASS |
| MadGraph import and cross section | PENDING_EXTERNAL_RUNTIME |
| Stable LLP in generated LHE | PENDING_EXTERNAL_RUNTIME |
| Pythia displaced decay | PENDING_EXTERNAL_RUNTIME |
| FastJet/recast A/B cutflow | PENDING_EXTERNAL_RUNTIME |
