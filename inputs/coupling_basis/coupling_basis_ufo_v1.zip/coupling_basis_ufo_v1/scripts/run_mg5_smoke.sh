#!/usr/bin/env bash
set -euo pipefail
PACK_ROOT=$(cd "$(dirname "$0")/.." && pwd)
POINT_DIR=${1:-"$PACK_ROOT/build/point_000001"}
[[ "$POINT_DIR" = /* ]] || POINT_DIR="$PACK_ROOT/$POINT_DIR"
MG5_BIN=${MG5_BIN:-$(command -v mg5_aMC || command -v mg5 || true)}
if [[ -z "$MG5_BIN" ]]; then
  echo "BLOCKED: set MG5_BIN to MadGraph 3.5.3 mg5_aMC" >&2
  exit 20
fi
cd "$PACK_ROOT"
[[ -f "$POINT_DIR/proc_card.dat" ]] || python scripts/build_point.py --config points/point_000001.yaml --output "$POINT_DIR"
"$MG5_BIN" "$POINT_DIR/proc_card.dat" | tee "$POINT_DIR/mg5_generate.log"
PROC="$POINT_DIR/MG5_PROC"
cp "$POINT_DIR/param_card.dat" "$PROC/Cards/param_card.dat"
python scripts/patch_mg5_run_card.py --source "$PROC/Cards/run_card.dat" --settings "$POINT_DIR/run_card.dat" --output "$PROC/Cards/run_card.dat.tmp"
mv "$PROC/Cards/run_card.dat.tmp" "$PROC/Cards/run_card.dat"
(
  cd "$PROC"
  ./bin/generate_events -f smoke | tee "$POINT_DIR/mg5_events.log"
)
LHE=$(find "$PROC/Events" -type f \( -name 'unweighted_events.lhe.gz' -o -name 'unweighted_events.lhe' \) | sort | tail -1)
[[ -n "$LHE" ]] || { echo 'FAIL: no LHE produced' >&2; exit 21; }
if [[ "$LHE" == *.gz ]]; then cp "$LHE" "$POINT_DIR/events.lhe.gz"; else cp "$LHE" "$POINT_DIR/events.lhe"; fi
python scripts/inspect_lhe.py "$LHE" --output "$POINT_DIR/lhe_report.json"
python scripts/extract_mg5_cross_section.py --point-dir "$POINT_DIR" --proc-dir "$PROC" --output "$POINT_DIR/cross_section.json"
echo "$LHE"
