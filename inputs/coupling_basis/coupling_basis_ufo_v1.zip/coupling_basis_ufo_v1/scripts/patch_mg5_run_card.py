#!/usr/bin/env python3
from __future__ import annotations
import argparse
import re
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--source', required=True, type=Path)
p.add_argument('--settings', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
a = p.parse_args()
settings = {}
for line in a.settings.read_text(encoding='utf-8').splitlines():
    raw = line.split('#',1)[0].strip()
    if not raw or '=' not in raw:
        continue
    value, name = raw.split('=',1)
    settings[name.strip().split()[0]] = value.strip()
text = a.source.read_text(encoding='utf-8')
seen = set()
out = []
for line in text.splitlines():
    match = re.match(r'^(\s*)([^#!]+?)\s*=\s*([A-Za-z0-9_]+)(.*)$', line)
    if match and match.group(3) in settings:
        name = match.group(3)
        line = f'{match.group(1)}{settings[name]} = {name}{match.group(4)}'
        seen.add(name)
    out.append(line)
missing = sorted(set(settings) - seen)
if missing:
    raise SystemExit(f'Could not patch run-card fields: {missing}')
a.output.write_text('\n'.join(out)+'\n', encoding='utf-8')
