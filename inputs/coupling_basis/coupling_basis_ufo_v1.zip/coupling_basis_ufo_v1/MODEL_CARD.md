# Model card

## Identity

- Pack: `coupling_basis_ufo_v1`
- Version: `1.0.0`
- Mediator: `H`, PDG 25, SM-like Higgs mass default 125 GeV
- LLP: `h2`, PDG 9000006, real neutral scalar
- Production: custom finite-mass `ggH` form factor followed by `H h2 h2`
- Initial validated multiplicity: zero additional partons only

## Coupling

The runtime UFO defines external `GHphiphi` in Les Houches block `BSMINPUTS`, code 1, and `GC_90 = i*GHphiphi` with coupling order `NP=1`.

Pack B modes:

- `PI_FIXED`: `GHphiphi = 8*mphi^2/v`.
- `2HDMC_ALIGNMENT`: `GHphiphi = (mh^2 + 2*mphi^2 - 2*Mbar2)/v`.
- `FREE_COUPLING`: exact user input `ghphiphi_GeV`.

`GHphiphi` is the real dimension-one coefficient. The UFO vertex contains the conventional factor `+i`; a global sign may differ from the convention used by 2HDMC/FeynRules.

## Lifetime and decays

Project input is `ctau_mm`. The historical UFO parameter `ctauh2` is metres and is set to `ctau_mm/1000`. The point builder uses

```text
Gamma_total[GeV] = 1.973269804e-13 / ctau_mm
Gamma_i = BR_i * Gamma_total
```

The generated `decay.slha` declares `bb`, `gg`, `gammagamma`, `Zgamma`, `WW`, and `ZZ`. Runtime support is pending until Pythia 8.308 executes the table successfully.
