# Changelog

    ## 1.0.0 — 2026-07-16

    - Derived from Pack A runtime.
- Added external `GHphiphi` in `BSMINPUTS`.
- Replaced fixed `GC_90` by `i*GHphiphi`.
- Replaced the negative order on that coupling with `NP=1`.
- Added PI, 2HDMC-alignment, and free-coupling point modes.
