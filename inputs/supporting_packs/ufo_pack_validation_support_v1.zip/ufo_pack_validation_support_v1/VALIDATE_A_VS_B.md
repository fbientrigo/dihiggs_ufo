# Validate Pack A versus Pack B

Use Pack A `point_000001` and Pack B `point_000001` (`PI_FIXED`). Keep identical mass, seed, PDF, collider energy, process and run settings.

Static acceptance is `EXACT_STATIC_MATCH` when the real coefficient, PDGs, particles, vertices, Lorentz structures, form factor, lifetime and BR contract match.

Runtime classification:

- `MONTE_CARLO_COMPATIBLE`: cross sections agree within the larger of 3 combined integration standard deviations or 2%; shape comparisons pass KS p-value > 0.01 for phi pT, pair invariant mass and rapidity; recast acceptance agrees within combined binomial uncertainty or 5% absolute relative tolerance when statistics are limited.
- `FAIL`: process/import mismatch, zero/invalid cross section, unstable contract mismatch, or incompatible distributions/acceptance.

Exact event-by-event identity is not required unless both generators and integration paths are deterministic under the same seed.
