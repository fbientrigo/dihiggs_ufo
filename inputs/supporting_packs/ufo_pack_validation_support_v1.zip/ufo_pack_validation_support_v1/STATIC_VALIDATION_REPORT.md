# Static validation report

Creation date: `2026-07-16T21:00:00-04:00`

## Verdicts

- Pack A: **PASS** for local static acceptance.
- Pack B: **PASS** for local static acceptance.
- A/B static regression: **EXACT_STATIC_MATCH**.
- End-to-end HEP validation: **PENDING_EXTERNAL_RUNTIME**.

## Executed locally

- safe ZIP extraction and path-traversal rejection logic;
- SHA-256 inventory;
- `python -m compileall`;
- static UFO imports and object inventories;
- Python-3 runtime writer execution;
- JSON Schema/YAML point validation;
- deterministic param-card and decay-SLHA generation;
- lifetime tests at 1, 5.1 and 100 mm;
- BR validation, negative/sum/unknown/closed-channel rejection;
- Pack A fixed-coupling checks at 100, 200 and 250 GeV;
- Pack B PI, free and 2HDMC-alignment modes, including free-coupling points at 50, 100 and 200 GeV;
- syntax-checked external MG5 cross-section extraction and quadratic-scaling comparator;
- scientific lint for negative QED order in Pack B, LLP decays in proc cards, width Auto, extra-parton samples, PDG and unit contract;
- static Pack A versus Pack B regression under `PI_FIXED`.

Full command logs are inside each ZIP under `validation/logs/`.

## Not executed here

MadGraph, Pythia, FastJet, and the DV+jets recast executables were absent. No cross section, LHE sample, displaced vertex metric, or cutflow is claimed.
## Final packaging QA

- both ZIPs were re-extracted with explicit path-traversal checks;
- all internal `checksums.sha256` entries verified;
- Python compilation was repeated with `SyntaxWarning` promoted to an error;
- strong assertions rechecked the fixed Pack A coupling, external Pack B coupling, `NP=1`, PDG 9000006, stable zero-jet process cards, lifetime and BR contracts;
- the MG5 cross-section parser and `sigma/|GHphiphi|^2` checker passed synthetic fixtures;
- two consecutive clean builds produced byte-identical ZIPs.

