# ChatGPT Work / Sol High mission — external HEP validation

Act as a senior HEP runtime validation engineer. Inputs are `pi_ufo_baseline_v1.zip`, `coupling_basis_ufo_v1.zip`, and the comparison/validation guides delivered with them. Use the available MadGraph 3.5.3, Pythia 8.308, FastJet 3.4.0, and local DV+jets recast.

Do not redesign the models. Execute and preserve evidence.

1. Verify ZIP SHA-256, extract safely, run each pack's Python static tests, and record versions/commit hashes.
2. For Pack A generate `g g > H > h2 h2` only, with stable h2 in the LHE. Produce at least 100 smoke events. Record import/generation logs, cross section and integration error. Require exactly two status-1 PDG 9000006 LLPs per event.
3. Run the bundled Pythia driver using `decay.slha`. Record configured tau0, generated proper time, L3D, Rxy, daughter multiplicities, and fraction Rxy > 4 mm. Preserve exact Pythia commands and any code patch.
4. Connect the showered output to both DV+jets variants A and B. Record upstream commit, patch hash, jet algorithm, efficiency-map settings and cutflows. Require the first physically nonzero DV cutflow.
5. Repeat Pack B for `PI_FIXED`, `FREE_COUPLING`, and `2HDMC_ALIGNMENT`. For FREE_COUPLING run at least three nonzero values at fixed mass and verify sigma scales approximately as |GHphiphi|^2, accounting for integration errors.
6. Run A versus B at PI_FIXED with identical mass, seed, PDF, scales and settings. Compare cross section, integration error, phi pT, pair invariant mass, rapidity, event structure and recast acceptance. Classify EXACT_STATIC_MATCH, MONTE_CARLO_COMPATIBLE, or FAIL using `VALIDATE_A_VS_B.md`.
7. Do not claim 1/2-parton validation, full 2HDM coverage, or physical UV-complete BRs.

Return a ZIP containing all logs, generated cards, LHE metadata, Pythia metrics, cutflows, plots, machine-readable status JSON, and a concise verdict for each acceptance gate. Patch only reproducibility/runtime defects; any physics change requires a separate derived version and explicit diff.
