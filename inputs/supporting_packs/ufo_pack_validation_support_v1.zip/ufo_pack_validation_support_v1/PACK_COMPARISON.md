# Pack comparison

| Property | Pack A — PI baseline | Pack B — coupling basis |
|---|---|---|
| UFO provenance | PI-provided v3 source preserved | Derived from Pack A runtime |
| H-h2-h2 coefficient | `8*mphi^2/v` internal | external `GHphiphi [GeV]` |
| Coupling order | historical `QED=-1` retained | `NP=1` |
| Modes | `PI_FIXED` | `PI_FIXED`, `2HDMC_ALIGNMENT`, `FREE_COUPLING` |
| LLP | PDG 9000006 | PDG 9000006 |
| Production | `g g > H > h2 h2` | same |
| LHE decay | forbidden | forbidden |
| Extra partons | blocked | blocked |
| Full 2HDM | no | no |

## Static regression

Status: **EXACT_STATIC_MATCH**.

With `mphi=200 GeV`, both packs produce `GHphiphi=1299.647715071661 GeV` under `PI_FIXED`. Particles, vertices, Lorentz structures and form-factor sources are byte-identical. The only intended physics changes in Pack B are the external parameter and coupling-order representation.

MadGraph cross sections, generated distributions, Pythia displacement, and recast acceptance remain `PENDING_EXTERNAL_RUNTIME`.
