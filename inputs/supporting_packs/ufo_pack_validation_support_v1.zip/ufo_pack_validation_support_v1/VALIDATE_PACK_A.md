# Validate Pack A

Pack: `pi_ufo_baseline_v1`. Mode: `PI_FIXED`.

```bash
python -m pip install -r requirements.txt
python scripts/build_point.py --config points/point_000001.yaml --output build/point_000001
python scripts/run_static_tests.py
MG5_BIN=/path/to/MG5_aMC_v3_5_3/bin/mg5_aMC scripts/run_mg5_smoke.sh build/point_000001
PYTHIA8_CONFIG=/path/to/pythia8-config scripts/run_pythia_smoke.sh build/point_000001
```

Or execute the top-level wrapper:

```bash
MG5_BIN=/path/to/mg5_aMC PYTHIA8_CONFIG=/path/to/pythia8-config ./run_validation_pack_a.sh
```

Require: nonzero `cross_section.json`; two stable status-1 PDG 9000006 particles per LHE event; no h2 daughters in the LHE; Pythia nonzero decay/lifetime observables; and, when `RECAST_CMD` plus `RECAST_INPUT` are supplied, nonempty cutflows A and B.
