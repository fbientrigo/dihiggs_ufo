# External validation guide

Validate in this order:

1. unpack each ZIP;
2. install Python requirements;
3. build `point_000001` and run static tests;
4. execute `scripts/run_mg5_smoke.sh` with MadGraph 3.5.3;
5. require a nonzero cross section and exactly two final-state PDG 9000006 entries per LHE event;
6. execute `scripts/run_pythia_smoke.sh` with Pythia 8.308;
7. require nonzero decays, configured tau0, generated proper times, L3D/Rxy, and a measured fraction above Rxy=4 mm;
8. connect the local DV+jets executable through `RECAST_CMD` and obtain nonempty cutflows A and B;
9. for Pack B run PI_FIXED, 2HDMC_ALIGNMENT, and FREE_COUPLING at 50, 100, and 200 GeV; require `coupling_scaling.json` to pass;
10. run A/B regression with matched masses, seeds, PDFs and run settings using `run_validation_ab.sh`.

The top-level wrappers execute these gates. Detailed files: `VALIDATE_PACK_A.md`, `VALIDATE_PACK_B.md`, and `VALIDATE_A_VS_B.md`.
