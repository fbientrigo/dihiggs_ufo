# Validate Pack B

Pack: `coupling_basis_ufo_v1`. Modes: `PI_FIXED`, `2HDMC_ALIGNMENT`, and `FREE_COUPLING`.

The top-level wrapper builds and runs PI_FIXED, 2HDMC_ALIGNMENT, and FREE_COUPLING at 50, 100, and 200 GeV:

```bash
MG5_BIN=/path/to/MG5_aMC_v3_5_3/bin/mg5_aMC \
PYTHIA8_CONFIG=/path/to/pythia8-config \
./run_validation_pack_b.sh
```

Manual example:

```bash
python -m pip install -r requirements.txt
python scripts/run_static_tests.py
python scripts/build_point.py --config points/point_free_100.yaml --output build/point_free_100
MG5_BIN=/path/to/mg5_aMC scripts/run_mg5_smoke.sh build/point_free_100
PYTHIA8_CONFIG=/path/to/pythia8-config scripts/run_pythia_smoke.sh build/point_free_100
python scripts/check_coupling_scaling.py \
  build/point_free_050 build/point_free_100 build/point_free_200 \
  --output build/coupling_scaling.json
```

Require the same stable-LLP and displaced-decay conditions as Pack A. `coupling_scaling.json` must pass the approximately quadratic cross-section test. Recast execution additionally requires a point-specific HepMC/input path and `RECAST_CMD`.
